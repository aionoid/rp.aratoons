# Changelog

## [1.5.8] - 2026-07-25

### Added
- Navigation: Page catalog selector between category and titles (Page 1 (1-100), Page 2 (101-200), ...)
- Navigation: Movies/Series sub-menus now show "All" (الكل) instead of repeating the parent label

### Changed
- Back button on title pages now returns to page selector instead of home

## [1.5.7] - 2026-07-25

### Fixed
- UI: Poster images with relative paths from StarDima's JSON API (e.g. `posters/...`) now resolve to full URLs instead of broken `https://posters/...`

## [1.5.6] - 2026-07-25

### Fixed
- Playback: Earnvids, Uqload, and Lulustream HLS streams now use `inputstream.ffmpegdirect` instead of `inputstream.adaptive` (which could not handle their HLS media playlists, causing 30-second timeout and demuxer errors)
- Playback: Earnvids streams now use `index-v1-a1.m3u8` (direct media playlist) instead of `master.m3u8` (multi-level index), reducing start-up delay

## [1.5.5] - 2026-07-24

### Added
- Kids TV: Dedicated playback method setting (defaults to Prefer 576p/SD) independent from global playback setting

## [1.5.4] - 2026-07-24

### Added
- Resolution presets: Prefer 1080p/720p/576p/468p/360p/288p (no popup, silent selection)
- High-res logo overrides for scraped Kids TV channels (MBC 3, Rotana Kids, Karameesh, Majid Kids, Spacetoon, Cartoon Arabia, TRT Cocuk, Moonbug, Afarin TV, Toon Goggles)

### Changed
- Direct channels now appear first in Kids TV list (higher priority)
- Case-insensitive channel dedup (prevents duplicate MBC 3 entries)
- Fixed clearkey DRM scheme for shahid_shaka channels
- Improved Spacetoon logo URL (broken Wikimedia link replaced)

### Removed
- 11 dead/unreliable channels: 4Kids TV, 90's Kids, Disney Channel, Disney Junior, Disney XD, Lego Channel, KidsFlix, Kids Movie Club, LEGO Kids TV, Nick Jr., Forever Kids
- Majid Kids (DRM-protected, not playable on Kodi)

## [1.5.3] - 2026-07-24

### Added
- Kids TV: Added "MBC 3 DZ" channel (edgenextcdn.net stream)
- Kids TV: Added "Majid Kids DZ" channel (starzplayarabia.com HLS stream)

### Changed
- Playback: Simplified resolution selection to "Select Quality Via Dialog" and "Auto Adaptive" (inputstream.adaptive handles quality natively)

### Fixed
- Playback: Fixed crash when playing TV channels caused by filtered HLS playlist approach (data URIs and local file:// playlists with https:// variants are not supported by inputstream.adaptive)
- Playback: Audio now loads correctly with all HLS streams by using master playlist instead of video-only variant URLs

## [1.5.2] - 2026-07-24

### Fixed
- elahmad.ru: Updated stream decryption for new encryption keys and dynamic `da_ta` structure
- elahmad.ru: Added Cryptodome fallback for AES decryption (Android has no `openssl`)
- elahmad.ru: Removed `Cryptodome.Util.Padding` import (not available in pycryptodome 3.4.3 shipped with Kodi)
- elahmad.ru: Removed Referer header for HLS streams (edgenextcdn.net CDN returns 403 with Referer)
- elahmad.ru: Added HLS master playlist variant resolution (Kodi cannot handle separate audio/video renditions)
- elahmad.ru: Reduced HTTP request artificial delay from 1.5s to 0.5s for faster channel start times
