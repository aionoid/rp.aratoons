# AraToons (plugin.video.stardima) - Kodi Addon

Kodi addon for StarDima.com Arabic anime/movie streaming site.

## Current Status

### Working Servers

| Server | Type | Status |
|--------|------|--------|
| Mixdrop | Direct MP4 | Working |
| Krakenfiles | Direct MP4 | Working (server sometimes on maintenance) |
| Uqload | JWPlayer m3u8 | Working (via inputstream.ffmpegdirect) |
| StreamHG | m3u8 HLS | Working (fixed) |
| Earnvids | JWPlayer m3u8 | Working (via inputstream.ffmpegdirect) |

### Non-Working Servers

| Server | Problem | Notes |
|--------|---------|-------|
| Lulustream | Returns 403 Forbidden | CDN blocks requests even with correct Referer/Origin headers. Token may expire quickly or require specific browser fingerprint. |
| Goodstream | No playable stream found | JWPlayer eval decoder returns None. May need different extraction logic. |
| Filemoon | Not tested | Unknown status |

## Key Fixes Applied

### 1. Eval Decoder - Base-36 (not Hex)
JS `eval(function(p,a,c,k,e,d)...)` uses `c.toString(36)` for keyword indices. Must use Base-36 decoding, not Hex (`format(i, 'x')`). Empty keywords must be skipped.

### 2. StreamHG URL Selection
The eval config contains TWO URLs:
- `.m3u8` with query params (e.g., `premilkyway.com`) - WORKS
- `.txt` without params (e.g., `sunsetfieldinnovation.store`) - BROKEN

Code was preferring `.txt` first. Fixed to prefer `.m3u8` first.

### 3. HLS Detection for .txt URLs
StreamHG returns m3u8 URLs ending in `.txt` (e.g., `master.txt`). Kodi checks `'.m3u8' in stream_url` which was False, so it used the default video player instead of inputstream.adaptive. Fixed to detect `.txt` and `master.txt` URLs as HLS.

### 4. Headers - Local Dict Instead of Global
`MEDIA_HEADERS` was a global dict that persisted stale Referer/Origin headers across calls. Fixed to use local headers dict in `_play_media`.

### 5. Kodi __pycache__ Caching
Kodi caches `.pyc` bytecode. After each update, must:
1. Extract zip to addon directory
2. Delete all `__pycache__` directories
3. Touch source files to make them newer than any pyc

### 6. Server Selection Menu
When user clicks play, a dialog shows available servers with status (ready/processing). User picks the server to use. Faster than auto-trying each one sequentially.

### 7. URL Verification
JWPlayer servers (Lulustream, Uqload) are verified with a GET request before returning. If the URL returns 403 or invalid content, the addon skips to the next server.

### 8. HLS Playback via inputstream.ffmpegdirect
Earnvids, Uqload, and Lulustream return HLS playlists that `inputstream.adaptive` cannot handle properly (media playlists without `#EXT-X-STREAM-INF` variants, CDN auth issues). Fixed by routing these servers through `inputstream.ffmpegdirect` which handles them natively via FFmpeg's libavformat.

### 9. Earnvids Fast Playback
Earnvids `master.m3u8` is a multi-level index that takes 30+ seconds to resolve. Fixed by replacing `master.m3u8` with `index-v1-a1.m3u8` (direct media playlist) for instant playback.

## Deployment Process

```bash
# Build zip
python3 build.py  # or use the execute_code script

# Extract to addon dir
unzip ~/.kodi/addons/plugin.video.stardima.zip -d /tmp/stardima_extract/
cp -r /tmp/stardima_extract/plugin.video.stardima/* ~/.kodi/addons/plugin.video.stardima/

# Clear cache
find ~/.kodi/addons/plugin.video.stardima -name '__pycache__' -type d -exec rm -rf {} +

# Touch source files
touch ~/.kodi/addons/plugin.video.stardima/lib/sites/stardima.py
touch ~/.kodi/addons/plugin.video.stardima/lib/plugin.py
```

## Architecture

- `lib/plugin.py` - Main addon entry point, menu building, playback
- `lib/sites/stardima.py` - StarDima scraping, stream resolution, eval decoders
- `lib/network.py` - HTTP request helper with session management
- `lib/common.py` - Shared utilities
- `lib/constants.py` - Addon constants
- `lib/recently_watched.py` - Recently watched tracking

## Stream Resolution Flow

1. Fetch StarDima page -> find hyperwatching embed URL
2. Fetch hyperwatching page -> parse `data-page` JSON for hashid + servers list
3. For each server (in priority order):
   - Call hyperwatching API for embed URL
   - Fetch embed page
   - Extract stream URL (Mixdrop MP4, StreamHG m3u8, JWPlayer m3u8)
   - Verify URL is accessible (GET request)
   - Return URL + Referer header

## Server Priority

1. Mixdrop (direct MP4, most reliable)
2. Krakenfiles (direct MP4)
3. Uqload (JWPlayer m3u8)
4. StreamHG (m3u8 HLS)
5. Others (Goodstream, Filemoon, Earnvids, Lulustream)

## Known Issues

- Krakenfiles server occasionally on maintenance
- Lulustream returns 403 (CDN blocking)
- Goodstream extraction not implemented
- Cloudflare protection on StarDima may block requests (requires fresh session)
