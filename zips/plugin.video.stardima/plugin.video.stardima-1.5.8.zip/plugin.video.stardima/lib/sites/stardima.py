# -*- coding: utf-8 -*-
"""
StarDima site scraper — https://www.stardima.com

StarDima is a modern Laravel/Blade + Tailwind CSS site (Arabic RTL).
Uses JSON APIs for search, episodes, and episode data.
Uses HTML scraping for catalog pages.
"""

import re
import json
import xbmc
import xbmcgui
import xbmcplugin
import six

from lib.constants import BASEURL, STORAGE_URL, WNT2_USER_AGENT, PLUGIN_ID, PLUGIN_TITLE, ADDON, KODI_VERSION, PLAYBACK_METHOD, \
    PROPERTY_EPISODE_LIST_URL, PROPERTY_EPISODE_LIST_DATA, PROPERTY_LATEST_MOVIES, PROPERTY_INFO_ITEMS, ADDON_ICON_DICT
from lib.common import (
    ensure_full_url, base_url_remove, build_url, item_set_info,\
    makeListItem, makeListItemClean, unescapeHTMLText, ensure_url_schema,\
    getRawWindowProperty, setRawWindowProperty, getWindowProperty, setWindowProperty, ADDON_ICON,
)
from lib.network import rqs_get, request_helper

# ---------------------------------------------------------------------------
# SITE_SETTINGS — minimal stubs so plugin.py doesn't crash on access
# ---------------------------------------------------------------------------
SITE_SETTINGS = {
    'episode': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'latest': {
        'url': '/newrelases',
        'start': '',
        'end': '',
        'regex': '',
    },
    'latest_movies': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'series_search': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'episode_search': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'catalog': {
        'start': '',
        'start_alt': False,
        'end': '',
        'regex': '',
    },
    'chapter': {
        'regex': '',
    },
}

DECODE_SOURCE_REQUIRED = False


def premium_workaround_check(html, urls):
    """Stub: StarDima does not have premium workaround."""
    return False


# ---------------------------------------------------------------------------
# StarDima JSON API helpers
# ---------------------------------------------------------------------------
_API_HEADERS = {
    'User-Agent': WNT2_USER_AGENT,
    'X-Requested-With': 'XMLHttpRequest',
    'Accept': 'application/json, text/plain, */*',
}


def _resolve_poster(poster):
    """Resolve a poster_url from the StarDima JSON API.

    Full URLs (e.g. TMDB) are returned as-is.
    Relative paths (e.g. 'posters/foo.jpg') are resolved under /storage/.
    """
    if not poster:
        return ''
    if poster.startswith('http'):
        return poster
    return STORAGE_URL + '/' + poster


def _api_get(path):
    """GET a JSON API endpoint on StarDima."""
    url = BASEURL + path if path.startswith('/') else BASEURL + '/' + path
    r = request_helper(url, extra_headers=_API_HEADERS)
    return r.json()


def _search_api(query, page=1, all_pages=False):
    """Search API: returns {results: [...], last_page: N} for a single page,
    or all pages if all_pages=True (legacy mode)."""
    import urllib.parse as up
    url = BASEURL + '/search?query=' + up.quote_plus(query)
    if page > 1:
        url += '&page=' + str(page)
    r = request_helper(url, extra_headers=_API_HEADERS)
    data = r.json()
    results = []
    for v in data.get('videos', []):
        poster = v.get('poster_url', '')
        results.append({
            'url': v.get('url', ''),
            'title': v.get('title', ''),
            'poster_url': _resolve_poster(poster),
            'is_series': v.get('is_series', False),
            'year': v.get('year', ''),
            'description': v.get('description', ''),
        })

    pagination = data.get('pagination', {})
    last_page = pagination.get('last_page', 1)

    if all_pages:
        for pg in range(2, last_page + 1):
            page_url = url + '&page=' + str(pg)
            r2 = request_helper(page_url, extra_headers=_API_HEADERS)
            data2 = r2.json()
            for v in data2.get('videos', []):
                poster = v.get('poster_url', '')
                results.append({
                    'url': v.get('url', ''),
                    'title': v.get('title', ''),
                    'poster_url': _resolve_poster(poster),
                    'is_series': v.get('is_series', False),
                    'year': v.get('year', ''),
                    'description': v.get('description', ''),
                })
        return results

    return {'results': results, 'last_page': last_page, 'current_page': page}


def _get_seasons(series_slug):
    """Get seasons for a series by scraping the detail page."""
    url = BASEURL + '/tvshow/' + series_slug
    r = request_helper(url)
    html = r.text

    # Extract poster from meta og:image
    poster = ''
    m = re.search(r'<meta property="og:image"[^>]+content="([^"]+)"', html)
    if m:
        poster = m.group(1)

    # Extract description from meta
    desc = ''
    m = re.search(r'<meta name="description"[^>]+content="([^"]+)"', html)
    if m:
        desc = unescapeHTMLText(m.group(1))

    # Extract season ID: first try data-initial-season-id on the series page,
    # then fall back to scraping the first episode page for the actual season ID
    seasons = []

    # Try data-initial-season-id (most reliable)
    m = re.search(r'data-initial-season-id="(\d+)"', html)
    if m:
        seasons.append(m.group(1))

    # Fall back: find the first /play/ link, then scrape that episode page
    # for data-initial-season-id or data-season-id
    if not seasons:
        play_m = re.search(r'href="[^"]*/play/(\d+)"', html)
        if play_m:
            first_ep_id = play_m.group(1)
            ep_url = BASEURL + '/tvshow/' + series_slug + '/play/' + first_ep_id
            r2 = request_helper(ep_url)
            ep_html = r2.text
            # Extract season IDs from the episode page
            for m2 in re.finditer(r'data-initial-season-id="(\d+)"', ep_html):
                vid = m2.group(1)
                if vid not in seasons:
                    seasons.append(vid)
            for m2 in re.finditer(r'data-season-id="(\d+)"', ep_html):
                vid = m2.group(1)
                if vid not in seasons:
                    seasons.append(vid)

    # Final fallback: data-video-id (may point to wrong series on some pages)
    if not seasons:
        for m in re.finditer(r'data-video-id="(\d+)"', html):
            vid = m.group(1)
            if vid not in seasons:
                seasons.append(vid)

    return {'seasons': seasons, 'poster': poster, 'description': desc}


def _get_episodes(season_id):
    """Get episodes for a season via JSON API."""
    data = _api_get('/series/season/' + str(season_id))
    episodes = []
    series_id = data.get('series_id', '')
    for ep in data.get('episodes', []):
        episodes.append({
            'id': ep.get('id', ''),
            'title': ep.get('title', ''),
        })
    return {'episodes': episodes, 'series_id': series_id}


def _get_episode(episode_id):
    """Get episode data via JSON API. Returns watch_url."""
    data = _api_get('/series/episode/' + str(episode_id))
    episode = data.get('episode', {})
    series = data.get('series', {})
    return {
        'watch_url': episode.get('watch_url', ''),
        'can_watch': episode.get('can_watch', False),
        'reason': episode.get('reason', ''),
        'title': episode.get('title', ''),
        'series_slug': series.get('slug', ''),
    }


# ---------------------------------------------------------------------------
# HTML scraping helpers for catalog pages
# ---------------------------------------------------------------------------

def _scrape_catalog_items(html):
    """
    Scrape items from a StarDima catalog page (latest, series, movies).
    Returns list of (url, title, poster_url) tuples.
    """
    items = []
    item_blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', html)

    for block in item_blocks:
        link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie)/[^"]+)"', block)
        poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
        title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)

        if link_m and title_m:
            url = link_m.group(1)
            if not url.startswith('http'):
                url = 'https://' + url
            title = title_m.group(1).strip()
            poster = poster_m.group(1).strip() if poster_m else ''
            items.append((url, title, poster))

    return items


def _catalog_api_paginated(path, page=1, max_pages=1):
    """
    Fetch a catalog page via StarDima's JSON API (X-Requested-With: XMLHttpRequest).
    Loads multiple API pages (~7 pages of 15 = ~100 items) per call for a smooth
    browsing experience, since the server hardcodes 15 items per page.

    Returns {'items': [(url, title, poster), ...], 'last_page': N, 'current_page': page}
    where last_page is the number of virtual pages (each ~100 items).
    Handles paths with existing query params (e.g. /aflam?language=sub).
    """
    ITEMS_PER_API_PAGE = 15
    VIRTUAL_PAGE_SIZE = 100  # Target ~100 items per page
    API_PAGES_PER_VIRTUAL = max(1, VIRTUAL_PAGE_SIZE // ITEMS_PER_API_PAGE)  # 7 API pages

    def _build_items(videos):
        items = []
        for v in videos:
            v_url = v.get('url', '')
            v_title = v.get('title', '')
            v_poster = _resolve_poster(v.get('poster_url', ''))
            items.append((v_url, v_title, v_poster))
        return items

    def _build_url(pg):
        url = BASEURL + path
        if pg > 1:
            sep = '&' if '?' in path else '?'
            url += sep + 'page=' + str(pg)
        return url

    # First request to get total page count
    first_api_page = (page - 1) * API_PAGES_PER_VIRTUAL + 1
    r = request_helper(_build_url(first_api_page), extra_headers=_API_HEADERS)
    data = r.json()
    pagination = data.get('pagination', {})
    total_api_pages = pagination.get('last_page', 1)

    # Calculate virtual page count
    total_items = total_api_pages * ITEMS_PER_API_PAGE
    virtual_last_page = max(1, (total_items + VIRTUAL_PAGE_SIZE - 1) // VIRTUAL_PAGE_SIZE)

    # Fetch API pages for this virtual page
    items = []
    seen_urls = set()
    for offset in range(API_PAGES_PER_VIRTUAL):
        api_pg = first_api_page + offset
        if api_pg > total_api_pages:
            break
        r2 = request_helper(_build_url(api_pg), extra_headers=_API_HEADERS)
        data2 = r2.json()
        for v in data2.get('videos', []):
            v_url = v.get('url', '')
            if v_url in seen_urls:
                continue
            seen_urls.add(v_url)
            v_title = v.get('title', '')
            v_poster = _resolve_poster(v.get('poster_url', ''))
            items.append((v_url, v_title, v_poster))

    return {'items': items, 'last_page': virtual_last_page, 'current_page': page}


def _scrape_catalog_paginated(path, page=1, max_pages=1):
    """
    Scrape a catalog path. When max_pages=1 (default), returns a single page:
      {'items': [...], 'last_page': N, 'current_page': page}
    When max_pages>1, returns a flat list of items (legacy mode).
    Handles paths with existing query params (e.g. /aflam?language=sub).
    """
    url = BASEURL + path
    if page > 1:
        sep = '&' if '?' in path else '?'
        url += sep + 'page=' + str(page)
    r = request_helper(url)
    html = r.text

    page_items = _scrape_catalog_items(html)

    # Check pagination
    last_page_m = re.search(r'data-last-page="(\d+)"', html)
    last_page = int(last_page_m.group(1)) if last_page_m else 1

    if max_pages == 1:
        return {'items': page_items, 'last_page': last_page, 'current_page': page}

    # Legacy mode: fetch multiple pages
    items = list(page_items)
    seen_urls = {item[0] for item in page_items}
    for pg in range(2, max_pages + 1):
        if pg > last_page:
            break
        url2 = BASEURL + path
        sep = '&' if '?' in path else '?'
        url2 += sep + 'page=' + str(pg)
        r2 = request_helper(url2)
        page_items2 = _scrape_catalog_items(r2.text)
        for item_url, item_title, item_poster in page_items2:
            if item_url not in seen_urls:
                seen_urls.add(item_url)
                items.append((item_url, item_title, item_poster))
    return items


def _scrape_homepage_popular(html):
    """Scrape popular items from the homepage."""
    items = []
    # Popular items on homepage have similar structure
    # Look for movie links in the homepage
    item_blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', html)

    for block in item_blocks:
        link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie)/[^"]+)"', block)
        poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
        title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)

        if link_m and title_m:
            url = link_m.group(1)
            if not url.startswith('http'):
                url = 'https://' + url
            title = title_m.group(1).strip()
            poster = poster_m.group(1).strip() if poster_m else ''
            items.append((url, title, poster))

    return items


def _scrape_newreleases_by_tab():
    """
    Scrape /newrelases page and split into 3 tab sections:
      - NewEpisodes: episodes with /play/ URLs
      - NewMovies: movie items
      - NewSeries: series items
    """
    r = request_helper(BASEURL + '/newrelases')
    html = r.text

    episodes = []
    movies = []
    series = []

    # Split HTML by tab content sections
    ep_section_m = re.search(r'data-content="episodes"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)
    series_section_m = re.search(r'data-content="series"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)
    movies_section_m = re.search(r'data-content="movies"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)

    def _extract_items(section_html):
        """Extract items from a tab section's HTML."""
        if not section_html:
            return []
        items = []
        blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', section_html)
        for block in blocks:
            link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie|play)/[^"]+)"', block)
            poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
            title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)
            if not title_m:
                title_m = re.search(r'<h3[^>]+>[ \t]*([^<]+)[ \t]*</h3>', block)

            if link_m and title_m:
                url = link_m.group(1)
                if not url.startswith('http'):
                    url = 'https://' + url
                title = title_m.group(1).strip()
                poster = poster_m.group(1).strip() if poster_m else ''
                items.append((url, title, poster))
        return items

    episodes = _extract_items(ep_section_m.group(1) if ep_section_m else '')
    movies = _extract_items(movies_section_m.group(1) if movies_section_m else '')
    series = _extract_items(series_section_m.group(1) if series_section_m else '')

    return {
        'NewEpisodes': tuple(episodes),
        'NewMovies': tuple(movies),
        'NewSeries': tuple(series),
    }


# ---------------------------------------------------------------------------
# Stream resolution — full chain from StarDima to playable URL
# ---------------------------------------------------------------------------

def resolve_stardima_stream(url, server_name=None):
    """
    Resolve a StarDima video URL to a playable stream.
    If server_name is provided, only try that specific server.
    """
    import html as html_mod
    import urllib.parse as up
    import xbmc

    log = lambda msg: xbmc.log(f'AraToons: {msg}', xbmc.LOGINFO)
    log(f'resolving: {url} (server={server_name})')

    def _referer(base_url):
        """Extract origin URL for Referer header."""
        p = up.urlparse(base_url)
        return p.scheme + '://' + p.netloc + '/'

    embed_url = None

    # If already a hyperwatching URL, skip StarDima scraping
    if 'hyperwatching' in url:
        embed_url = url
    else:
        # Step 1: Get hyperwatching embed URL from StarDima play page
        r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
        star_html = r.text

        # Handle movie detail pages — redirect to /play/{id}
        if '/movie/' in url and '/play/' not in url:
            movie_id_m = re.search(r'/movie/([^?/]+)', url)
            if movie_id_m:
                url = BASEURL + '/play/' + movie_id_m.group(1)
                r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
                star_html = r.text

        og_m = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
        if og_m:
            og_video = og_m.group(1)
            # Only use og:video if it points to an external embed (hyperwatching)
            if 'hyperwatching' in og_video or 'stardima' not in og_video:
                embed_url = og_video

        if not embed_url:
            # Try iframe src
            iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', star_html)
            if iframe_m:
                embed_url = iframe_m.group(1)

        if not embed_url:
            # Try to find play link on the page and follow it
            play_m = re.search(r'href="((?:https://)?(?:www\.)?stardima\.com/play/[^"]+)"', star_html)
            if play_m:
                play_url = play_m.group(1)
                if not play_url.startswith('http'):
                    play_url = 'https://' + play_url
                r = request_helper(play_url, extra_headers={'Referer': BASEURL + '/'})
                star_html = r.text
                og_m2 = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
                if og_m2:
                    embed_url = og_m2.group(1)

        if not embed_url:
            # Cloudflare blocked the page — try episode API for /play/ URLs
            ep_match = re.search(r'/play/(\d+)$', url)
            if ep_match:
                episode_id = ep_match.group(1)
                ep_data = _get_episode(episode_id)
                watch_url = ep_data.get('watch_url', '')
                if watch_url:
                    embed_url = watch_url

    if not embed_url:
        log('no embed_url found')
        return None

    # Step 2: Fetch hyperwatching page and parse data-page JSON
    r2 = request_helper(embed_url, extra_headers={'Referer': url})
    hw_html = r2.text

    data_page_m = re.search(r'data-page="([^"]+)"', hw_html)
    if not data_page_m:
        return None

    data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
    video = data_page.get('props', {}).get('video', {})
    hashid = video.get('hashid', '')
    servers = video.get('servers', [])

    if not hashid or not servers:
        log(f'no hashid/servers: hashid={hashid}, servers={len(servers)}')
        return None

    # If a specific server is requested, filter to only that one
    if server_name:
        matched = [s for s in servers if s.get('name', '') == server_name and s.get('id', 0) != 0]
        if matched:
            servers = matched
        else:
            log(f'server {server_name} not found')
            return None

    # Step 3: Try all servers — Mixdrop first (direct MP4), then StreamHG (m3u8)
    server_order = []
    priority_servers = []  # [Mixdrop, StreamHG]
    other_servers = []
    for s in servers:
        if s.get('id', 0) == 0:
            continue
        name = s.get('name', '')
        if name in ('Mixdrop', 'Streamhg', 'Uqload', 'Earnvids', 'Goodstream'):
            priority_servers.append(s)
        else:
            other_servers.append(s)
    # Order: Mixdrop first, then Uqload, StreamHG, Earnvids, Goodstream
    priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Streamhg': 2, 'Earnvids': 3, 'Goodstream': 4}
    priority_servers.sort(key=lambda s: priority_order.get(s.get('name', ''), 99))
    server_order = priority_servers + other_servers

    hw_base = 'https://v2.hyperwatching.com'

    for server in server_order:
        server_id = server.get('id', 0)
        name = server.get('name', '')
        log(f'trying server: {name} (id={server_id})')

        api_url = '{}/embed/{}/server/{}/url'.format(hw_base, hashid, server_id)
        r3 = request_helper(api_url, extra_headers={'Referer': embed_url})
        try:
            api_data = r3.json()
        except Exception:
            continue

        watch_url = api_data.get('watch_url', '')
        if not watch_url:
            log(f'  no watch_url from API')
            continue

        # Step 4: Fetch the embed page and try to extract stream URL
        r4 = request_helper(watch_url, extra_headers={'Referer': embed_url})
        player_html = r4.text
        log(f'  watch_url: {watch_url}')

        # --- Mixdrop: extract MP4 URL from eval() config ---
        if name == 'Mixdrop':
            mp4_url = _extract_mixdrop_url(player_html)
            log(f'  Mixdrop result: {mp4_url}')
            if mp4_url:
                return (mp4_url, _referer(watch_url))

         # --- Direct hgplaycdn.com (StreamHG) ---
        if 'hgplaycdn.com' in watch_url:
            m3u8_url = _extract_streamhg_url(player_html)
            log(f'  StreamHG direct result: {m3u8_url}')
            if m3u8_url:
                verified = _verify_stream_url(m3u8_url, _referer(watch_url))
                if verified:
                    return (m3u8_url, _referer(watch_url))
                log(f'  StreamHG URL not accessible, trying next server')
                continue

        # --- Filemoon: try to extract m3u8 from the page ---
        if 'filemoon' in watch_url or 'filemoon' in player_html:
            fm_url = _extract_filemoon_url(watch_url, player_html, embed_url)
            log(f'  Filemoon result: {fm_url}')
            if fm_url:
                return (fm_url, _referer(watch_url))

        # --- Earnvids (minochinos.com): eval-encoded JWPlayer ---
        if 'minochinos.com' in watch_url or 'earnvids' in watch_url or 'earnvids' in player_html:
            ev_url = _extract_earnvids_url(player_html)
            log(f'  Earnvids result: {ev_url}')
            if ev_url:
                return (ev_url, _referer(watch_url))

        # --- All servers: try to extract m3u8/MP4 from page ---
        m3u8_m = re.search(r'src="([^"]*\.m3u8[^"]*)"', player_html)
        if m3u8_m:
            return (m3u8_m.group(1), _referer(watch_url))

        src_m = re.search(r'<source[^>]+src="([^"]+)"', player_html)
        if src_m:
            return (src_m.group(1), _referer(watch_url))

        data_src_m = re.search(r'data-(?:src|url)="([^"]*\.m3u8[^"]*)"', player_html)
        if data_src_m:
            return (data_src_m.group(1), _referer(watch_url))

        # --- Strema.top proxy: extract the actual embed URL and try directly ---
        if 'strema.top' in watch_url:
            import urllib.parse as up
            parsed = up.urlparse(watch_url)
            params = up.parse_qs(parsed.query)
            if 'id' in params:
                actual_url = up.unquote(params['id'][0])

                # Try fetching the actual embed page directly first
                # Cloudflare-protected domains (Lulustream, Goodstream) are handled by request_helper
                r5 = request_helper(actual_url, extra_headers={'Referer': watch_url})
                actual_html = r5.text
                log(f'  actual_url: {actual_url} (html={len(actual_html)} bytes)')

                # If the actual page is an error (File not found / Cloudflare challenge),
                # try extracting from the strema.top JWPlayer page instead
                # But: pages with <video>/<source> tags are valid embed pages even if
                # they mention "cloudflare" or "not found" in footer text
                has_video_content = ('<video' in actual_html or '<source' in actual_html)
                # Pages with JWPlayer eval() are valid player pages, not errors
                has_jwplayer = 'eval(function(p,a,c,k,e,d)' in actual_html
                strema_has_error = (not has_video_content and not has_jwplayer and (
                    'not found' in actual_html.lower() or
                    'file has been deleted' in actual_html.lower() or
                    ('challenge' in actual_html.lower() and 'cloudflare' in actual_html.lower()) or
                    len(actual_html) < 200))

                if not strema_has_error:
                    # Try StreamHG decoder for hgplaycdn
                    if 'hgplaycdn.com' in actual_url:
                        m3u8_url = _extract_streamhg_url(actual_html)
                        log(f'  StreamHG (via strema) result: {m3u8_url}')
                        if m3u8_url:
                            verified = _verify_stream_url(m3u8_url, _referer(actual_url))
                            if verified:
                                return (m3u8_url, _referer(actual_url))
                            log(f'  StreamHG URL not accessible, trying next server')
                            continue

                    # --- Goodstream: extract m3u8 from JWPlayer config ---
                    if 'goodstream' in actual_url:
                        gs_url = _extract_goodstream_url(actual_html)
                        log(f'  Goodstream result: {gs_url}')
                        if gs_url:
                            # Clean JWPlayer URL artifacts (e.g., _,l,n,h,.urlset)
                            gs_url = _clean_jwplayer_url(gs_url)
                            log(f'  Goodstream cleaned: {gs_url}')
                            return (gs_url, _referer(actual_url))

                # Try JWPlayer decoder for lulustream/lulucdn/uqload etc.
                # When strema_has_error is True, use player_html (strema.top page)
                # instead of actual_html which returned an error.
                jw_source_html = actual_html if not strema_has_error else player_html
                jw_url = _extract_jwplayer_url(jw_source_html)
                log(f'  JWPlayer result: {jw_url}')
                if jw_url:
                    # Clean URL artifacts from base-36 decoding (Uqload)
                    jw_url = _clean_jwplayer_url(jw_url)
                    log(f'  JWPlayer cleaned: {jw_url}')
                    referer = _referer(actual_url if not strema_has_error else watch_url)
                    # Extract cookies for Uqload HLS auth
                    cookie = _extract_jwplayer_cookies(jw_source_html)
                    if cookie:
                        log(f'  JWPlayer cookies: {cookie}')
                    verified = _verify_stream_url(jw_url, referer, cookie)
                    if verified:
                        return (jw_url, referer)
                    log(f'  JWPlayer URL not accessible, trying next server')
                    continue

    log('no playable stream found')
    return None


def get_stardima_servers(url):
    """Return list of available servers for a given URL."""
    import html as html_mod
    r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
    star_html = r.text
    og_m = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
    og_video = og_m.group(1) if og_m else ''
    embed_url = ''
    if og_video:
        if 'hyperwatching' in og_video or 'stardima' not in og_video:
            embed_url = og_video
    if not embed_url:
        iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', star_html)
        if iframe_m:
            embed_url = iframe_m.group(1)
    if not embed_url:
        play_m = re.search(r'href="((?:https://)?(?:www\.)?stardima\.com/play/[^"]+)"', star_html)
        if play_m:
            play_url = play_m.group(1)
            if not play_url.startswith('http'):
                play_url = 'https://' + play_url
            r = request_helper(play_url, extra_headers={'Referer': BASEURL + '/'})
            star_html = r.text
            og_m2 = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
            if og_m2:
                embed_url = og_m2.group(1)
    if not embed_url:
        ep_match = re.search(r'/play/(\d+)$', url)
        if ep_match:
            ep_data = _get_episode(ep_match.group(1))
            watch_url = ep_data.get('watch_url', '')
            if watch_url:
                embed_url = watch_url
    if not embed_url:
        return []
    r2 = request_helper(embed_url, extra_headers={'Referer': url})
    data_page_m = re.search(r'data-page="([^"]+)"', r2.text)
    if not data_page_m:
        return []
    data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
    servers = data_page.get('props', {}).get('video', {}).get('servers', [])
    priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Streamhg': 2, 'Earnvids': 3, 'Goodstream': 4}
    result = []
    for s in servers:
        if s.get('id', 0) == 0:
            continue
        name = s.get('name', '')
        status = s.get('status', '')
        label = name + (' (ready)' if status == 'completed' else ' (processing)')
        result.append({'name': name, 'label': label, 'priority': priority_order.get(name, 99)})
    result.sort(key=lambda s: s['priority'])
    return result


def _verify_stream_url(url, referer, cookie=None):
    """Quick GET request to verify a stream URL returns valid content."""
    import urllib.request
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0',
        'Referer': referer,
        'Origin': referer.rsplit('/', 1)[0],
    }
    if cookie:
        headers['Cookie'] = cookie
    req = urllib.request.Request(url, method='GET', headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        if resp.status != 200:
            return False
        # Verify actual content is valid (m3u8 or mp4)
        data = resp.read(200)
        content_type = resp.headers.get('content-type', '')
        if 'm3u8' in url or 'mpegurl' in content_type:
            return b'#EXTM3U' in data
        elif 'mp4' in url or 'octet-stream' in content_type or 'mp4' in content_type:
            return len(data) > 100
        return len(data) > 50
    except Exception:
        return False


def _to_base36(n):
    """Convert integer to base-36 string (same as JS c.toString(36))."""
    if n == 0:
        return '0'
    chars = '0123456789abcdefghijklmnopqrstuvwxyz'
    result = ''
    while n > 0:
        result = chars[n % 36] + result
        n //= 36
    return result


def _extract_mixdrop_url(html):
    """Extract direct MP4 URL from Mixdrop embed page eval() config.

    Mixdrop uses eval with e=function(c){return c} (identity, NOT base-36).
    The keyword tokens are just the decimal index number.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    # Check whether it's Mixdrop identity decoder or base-36
    chunk = html[pos:pos+300]
    is_identity = 'return c}' in chunk and 'toString' not in chunk

    # Find the encoded string start - Mixdrop uses }(' while others use }('
    enc_start = html.find("}('", pos)
    if enc_start < 0:
        return None
    enc_start += 3  # Skip }('

    rest = html[enc_start:]
    # Find the end: encoded_string',base,count,'keywords
    # Look for the split marker
    split_marker = "'.split('|'),0,{}))"
    split_pos = rest.find(split_marker)
    if split_pos < 0:
        return None

    # Extract call args
    call_args = rest[:split_pos]
    # Find: encoded_string',base,count,'keywords
    close_m = re.search(r"',(\d+),(\d+),'(.*)$", call_args)
    if not close_m:
        return None

    encoded = call_args[:close_m.start()]
    count = int(close_m.group(2))
    keywords = close_m.group(3).split('|')

    # Decode - Mixdrop uses identity (decimal), others use base-36
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if i >= len(keywords) or not keywords[i]:
            continue
        token = str(i) if is_identity else _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(token) + r'(?!\w)', re.escape(keywords[i]), decoded)

    wurl_m = re.search(r'wurl["\']?\s*=\s*"([^"]+\.mp4[^"]*)"', decoded)
    if wurl_m:
        mp4 = wurl_m.group(1)
        if not mp4.startswith('http'):
            mp4 = 'https:' + mp4 if mp4.startswith('//') else 'https://' + mp4
        return mp4

    furl_m = re.search(r'furl["\']?\s*=\s*"([^"]+\.mp4[^"]*)"', decoded)
    if furl_m:
        mp4 = furl_m.group(1)
        if not mp4.startswith('http'):
            mp4 = 'https:' + mp4 if mp4.startswith('//') else 'https://' + mp4
        return mp4

    return None


def _extract_jwplayer_url(html):
    """Extract stream URL from JWPlayer eval() config.

    The eval function uses c.toString(36) (base-36) not hex.
    Skips empty keywords (like eval's if(k[c])).
    Returns plain string URL (same as streamhg branch).
    """
    pos = html.find('eval(function(p,a,c,k,e,d){while(c--)')
    if pos < 0:
        pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        return None
    enc_start += len("return p}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    count = int(close_m.group(2))
    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None

    keywords = after[:split_pos].split('|')

    # Decode using base-36 (same as eval's c.toString(36))
    # Process descending, skip empty keywords (like eval's if(k[c]))
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', re.escape(keywords[i]), decoded)

    # Find m3u8 or mp4 URL in decoded config
    m3u8_m = re.search(r'(https?://[^"\'\\]+\.m3u8[^"\'\\]*)', decoded)
    if m3u8_m:
        return m3u8_m.group(1)

    mp4_m = re.search(r'(https?://[^"\'\\]+\.mp4[^"\'\\]*)', decoded)
    if mp4_m:
        return mp4_m.group(1)

    return None


def _clean_jwplayer_url(url):
    """Clean JWPlayer URLs that have empty-keyword artifacts in the path.

    Uqload's JWPlayer encoding produces paths like:
    /12m5mlugpx5n_,l,n,h,.urlset/master.m3u8
    which should be:
    /12m5mlugpx5n_n/master.m3u8

    The ,X,Y,Z,.garbage pattern is caused by empty keyword placeholders
    that remain as literal characters after base-36 decoding.
    """
    # Pattern: /FILE_ID_,tok1,tok2,tok3,...,.garbage/master
    # The quality suffix is the second token (e.g., 'n' for normal)
    m = re.search(r'(/[^,]+_),([^,]+),([^,]+),([^,]+),\.[^/]*/master', url)
    if m:
        base_path = m.group(1)
        quality = m.group(3)
        url = url.replace(m.group(0), f'{base_path}{quality}/master')
    return url


def _extract_jwplayer_cookies(html):
    """Extract $.cookie() values from JWPlayer page for Uqload."""
    cookies = []
    for m in re.finditer(r"\.cookie\(['\"]([^'\"]+)['\"],\s*['\"]([^'\"]+)['\"]", html):
        cookies.append(f'{m.group(1)}={m.group(2)}')
    return '; '.join(cookies) if cookies else ''


def _extract_streamhg_url(html):
    """Extract m3u8 URL from StreamHG (hgplaycdn.com) eval config.

    Uses base-36 decoding like _extract_jwplayer_url.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        return None
    enc_start += len("return p}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    count = int(close_m.group(2))
    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None
    keywords = after[:split_pos].split('|')

    # Decode using base-36 (same as eval's c.toString(36))
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', re.escape(keywords[i]), decoded)

    # Find the m3u8 URL - prefer .m3u8 (with query params) over .txt (bare)
    for m in re.finditer(r'(https?://[^\s"\'`<>,;]{30,})', decoded):
        url = m.group(1).rstrip('",;')
        if 'master' in url and '.m3u8' in url:
            return url

    for m in re.finditer(r'(https?://[^\s"\'`<>,;]{30,})', decoded):
        url = m.group(1).rstrip('",;')
        if 'master' in url and '.txt' in url:
            return url

    return None


def _extract_filemoon_url(watch_url, player_html, embed_url):
    """Extract m3u8 URL from Filemoon embed page.

    Filemoon uses an iframe on a subdomain (e.g. q8y5z.com).
    We fetch the iframe page and try to extract the stream URL
    from JWPlayer config or direct src attributes.

    Note: Filemoon uses ECDSA signing + PoW captcha + AES-GCM
    encryption for the API flow. This is too complex for the
    addon environment. We fall back to extracting from page HTML.
    """
    # Look for iframe src in the Filemoon page
    iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', player_html)
    if not iframe_m:
        return None

    iframe_url = iframe_m.group(1)
    if not iframe_url.startswith('http'):
        iframe_url = 'https:' + iframe_url if iframe_url.startswith('//') else 'https://' + iframe_url

    # Fetch the iframe page
    try:
        r = request_helper(iframe_url, extra_headers={'Referer': watch_url})
        iframe_html = r.text
    except Exception:
        return None

    # Try to find m3u8 URL directly in the iframe HTML
    m3u8_m = re.search(r'(https?://[^"\'\s]+master[^"\'\s]*\.m3u8[^"\'\s]*)', iframe_html)
    if m3u8_m:
        return m3u8_m.group(1)

    # Try JWPlayer eval decoder
    jw_result = _extract_jwplayer_url(iframe_html)
    if jw_result:
        return jw_result

    # Try to find any m3u8 URL in the page
    for m in re.finditer(r'(https?://[^"\'\s]{30,})', iframe_html):
        url = m.group(1).rstrip('",;')
        if '.m3u8' in url or '.txt' in url:
            return url

    return None


def _extract_goodstream_url(html):
    """Extract m3u8 URL from Goodstream JWPlayer config.

    Goodstream has the URL in plain text inside jwplayer().setup({sources:...}).
    """
    # Find jwplayer setup with sources containing the m3u8 URL
    m = re.search(r'sources:\s*\[\s*\{\s*file:\s*["\']([^"\']+\.m3u8[^"\']*)["\']', html)
    if m:
        return m.group(1)

    # Fallback: find any .m3u8 URL in the page
    m = re.search(r'(https?://[^"\'\s]+\.m3u8[^"\'\s]*)', html)
    if m:
        return m.group(1)

    return None


def _extract_earnvids_url(html):
    """Extract m3u8 URL from Earnvids eval-encoded JWPlayer config.

    Earnvids uses eval(function(p,a,c,k,e,d)...) with base-36 decoding,
    same as the existing JWPlayer decoder.

    The master.m3u8 playlist is a multi-level index that takes a long time
    to resolve (player has to fetch each nested level). Replace it with
    index-v1-a1.m3u8 which is the direct single-variant playlist that
    plays immediately.

    NOTE: index-v1-a1.m3u8 is a media playlist (no #EXT-X-STREAM-INF),
    so it must be played with Kodi's default player, NOT inputstream.adaptive.
    Returns (url, referer, is_earnvids) — caller should use default player.
    """
    result = _extract_jwplayer_url(html)
    if result and 'master.m3u8' in result:
        result = result.replace('master.m3u8', 'index-v1-a1.m3u8')
    return result
