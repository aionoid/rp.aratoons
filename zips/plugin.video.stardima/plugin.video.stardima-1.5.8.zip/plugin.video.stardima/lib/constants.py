# -*- coding: utf-8 -*-

import sys
import xbmcaddon

IMAGES_URL = 'https://img.stardima.com'

THUMBS_BASEURL = 'https://doko-desuka.github.io/128h/'

PLUGIN_ID = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]
PLUGIN_NAME = PLUGIN_URL.replace("plugin://", "")
PLUGIN_TITLE = 'AraToons'

WNT2_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36'

ADDON = xbmcaddon.Addon()

BASEURL = 'https://www.stardima.com'
STORAGE_URL = BASEURL + '/storage'
BASEDOMAIN = 'stardima.com'

WATCH_BASEURL = 'https://watch.stardima.com/watch'
WATCH_API = WATCH_BASEURL + '/wp-json/wp/v2'

PROPERTY_CATALOG_PATH = 'stardima.catalogPath.' + BASEDOMAIN
PROPERTY_CATALOG = 'stardima.catalog.' + BASEDOMAIN
PROPERTY_EPISODE_LIST_URL = 'stardima.listURL.' + BASEDOMAIN
PROPERTY_EPISODE_LIST_DATA = 'stardima.listData.' + BASEDOMAIN
PROPERTY_LATEST_MOVIES = 'stardima.latestMovies.' + BASEDOMAIN
PROPERTY_INFO_ITEMS = 'stardima.infoItems.' + BASEDOMAIN
PROPERTY_SESSION_COOKIE = 'stardima.cookie.' + BASEDOMAIN

ADDON_SHOW_CATALOG = ADDON.getSetting('showCatalog') == 'true'
ADDON_LATEST_DATE = ADDON.getSetting('useLatestDate') == 'true'
ADDON_LATEST_THUMBS = ADDON.getSetting('showLatestThumbs') == 'true'
ADDON_CATALOG_THUMBS = ADDON.getSetting('showCatalogThumbs') == 'true'
ADDON_POPULAR_THUMBS = ADDON.getSetting('showPopularThumbs') == 'true'
ADDON_SERIES_THUMBS = ADDON.getSetting('showSeriesThumbs') == 'true'
ADDON_VIDEO_FANART = ADDON.getSetting('showVideoFanart') == 'true'

ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_ICON_DICT = {'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'poster': ADDON_ICON}
RESOURCE_URL = 'special://home/addons/{0}resources/'.format(PLUGIN_NAME)

PLAYBACK_METHOD = ADDON.getSetting('playbackMethod')

KODI_VERSION = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

MEDIA_HEADERS = None

URL_PATHS = {
    'latest_episodes': '/newrelases#episodes',
    'latest_movies': '/newrelases#movies',
    'latest_series': '/newrelases#series',
    'movies': '/aflam',
    'movies_sub': '/aflam?language=sub',
    'movies_dub': '/aflam?language=dub',
    'series': '/mosalsalat',
    'series_sub': '/mosalsalat?language=sub',
    'series_dub': '/mosalsalat?language=dub',
    'search': '/search',
}

# Watch.stardima.com paths
WATCH_PATHS = {
    'movies': WATCH_BASEURL + '/movies',
    'tvshows': WATCH_BASEURL + '/tvshows',
    'episodes': WATCH_BASEURL + '/episodes',
}

LANG_TYPES = [
    'sub',
    'dub',
]
