# -*- coding: utf-8 -*-
"""
StarDima site scraper — https://www.stardima.com

StarDima is a modern Laravel/Blade + Tailwind CSS site (Arabic RTL).
Uses JSON APIs for search, episodes, and episode data.
Uses HTML scraping for catalog pages.
"""

import re
import json
import xbmc
import xbmcgui
import xbmcplugin
import six

from lib.constants import BASEURL, STORAGE_URL, WNT2_USER_AGENT, PLUGIN_ID, PLUGIN_TITLE, ADDON, KODI_VERSION, PLAYBACK_METHOD, \
    PROPERTY_EPISODE_LIST_URL, PROPERTY_EPISODE_LIST_DATA, PROPERTY_LATEST_MOVIES, PROPERTY_INFO_ITEMS, ADDON_ICON_DICT
from lib.common import (
    ensure_full_url, base_url_remove, build_url, item_set_info,\
    makeListItem, makeListItemClean, unescapeHTMLText, ensure_url_schema,\
    getRawWindowProperty, setRawWindowProperty, getWindowProperty, setWindowProperty, ADDON_ICON,
)
from lib.network import rqs_get, request_helper

# ---------------------------------------------------------------------------
# SITE_SETTINGS — minimal stubs so plugin.py doesn't crash on access
# ---------------------------------------------------------------------------
SITE_SETTINGS = {
    'episode': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'latest': {
        'url': '/newrelases',
        'start': '',
        'end': '',
        'regex': '',
    },
    'latest_movies': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'series_search': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'episode_search': {
        'start': '',
        'end': '',
        'regex': '',
    },
    'catalog': {
        'start': '',
        'start_alt': False,
        'end': '',
        'regex': '',
    },
    'chapter': {
        'regex': '',
    },
}

DECODE_SOURCE_REQUIRED = False


def premium_workaround_check(html, urls):
    """Stub: StarDima does not have premium workaround."""
    return False


# ---------------------------------------------------------------------------
# StarDima JSON API helpers
# ---------------------------------------------------------------------------
_API_HEADERS = {
    'User-Agent': WNT2_USER_AGENT,
    'X-Requested-With': 'XMLHttpRequest',
    'Accept': 'application/json, text/plain, */*',
}


def _resolve_poster(poster):
    """Resolve a poster_url from the StarDima JSON API.

    Full URLs (e.g. TMDB) are returned as-is.
    Relative paths (e.g. 'posters/foo.jpg') are resolved under /storage/.
    """
    if not poster:
        return ''
    if poster.startswith('http'):
        return poster
    return STORAGE_URL + '/' + poster


def _api_get(path):
    """GET a JSON API endpoint on StarDima."""
    url = BASEURL + path if path.startswith('/') else BASEURL + '/' + path
    r = request_helper(url, extra_headers=_API_HEADERS)
    return r.json()


def _search_api(query, page=1, all_pages=False):
    """Search API: returns {results: [...], last_page: N} for a single page,
    or all pages if all_pages=True (legacy mode)."""
    import urllib.parse as up
    url = BASEURL + '/search?query=' + up.quote_plus(query)
    if page > 1:
        url += '&page=' + str(page)
    r = request_helper(url, extra_headers=_API_HEADERS)
    data = r.json()
    results = []
    for v in data.get('videos', []):
        poster = v.get('poster_url', '')
        results.append({
            'url': v.get('url', ''),
            'title': v.get('title', ''),
            'poster_url': _resolve_poster(poster),
            'is_series': v.get('is_series', False),
            'year': v.get('year', ''),
            'description': v.get('description', ''),
        })

    pagination = data.get('pagination', {})
    last_page = pagination.get('last_page', 1)

    if all_pages:
        for pg in range(2, last_page + 1):
            page_url = url + '&page=' + str(pg)
            r2 = request_helper(page_url, extra_headers=_API_HEADERS)
            data2 = r2.json()
            for v in data2.get('videos', []):
                poster = v.get('poster_url', '')
                results.append({
                    'url': v.get('url', ''),
                    'title': v.get('title', ''),
                    'poster_url': _resolve_poster(poster),
                    'is_series': v.get('is_series', False),
                    'year': v.get('year', ''),
                    'description': v.get('description', ''),
                })
        return results

    return {'results': results, 'last_page': last_page, 'current_page': page}


def _get_seasons(series_slug):
    """Get seasons for a series by scraping the detail page."""
    url = BASEURL + '/tvshow/' + series_slug
    r = request_helper(url)
    html = r.text

    # Extract poster from meta og:image
    poster = ''
    m = re.search(r'<meta property="og:image"[^>]+content="([^"]+)"', html)
    if m:
        poster = m.group(1)

    # Extract description from meta
    desc = ''
    m = re.search(r'<meta name="description"[^>]+content="([^"]+)"', html)
    if m:
        desc = unescapeHTMLText(m.group(1))

    # Extract season ID: first try data-initial-season-id on the series page,
    # then fall back to scraping the first episode page for the actual season ID
    seasons = []

    # Try data-initial-season-id (most reliable)
    m = re.search(r'data-initial-season-id="(\d+)"', html)
    if m:
        seasons.append(m.group(1))

    # Fall back: find the first /play/ link, then scrape that episode page
    # for data-initial-season-id or data-season-id
    if not seasons:
        play_m = re.search(r'href="[^"]*/play/(\d+)"', html)
        if play_m:
            first_ep_id = play_m.group(1)
            ep_url = BASEURL + '/tvshow/' + series_slug + '/play/' + first_ep_id
            r2 = request_helper(ep_url)
            ep_html = r2.text
            # Extract season IDs from the episode page
            for m2 in re.finditer(r'data-initial-season-id="(\d+)"', ep_html):
                vid = m2.group(1)
                if vid not in seasons:
                    seasons.append(vid)
            for m2 in re.finditer(r'data-season-id="(\d+)"', ep_html):
                vid = m2.group(1)
                if vid not in seasons:
                    seasons.append(vid)

    # Final fallback: data-video-id (may point to wrong series on some pages)
    if not seasons:
        for m in re.finditer(r'data-video-id="(\d+)"', html):
            vid = m.group(1)
            if vid not in seasons:
                seasons.append(vid)

    return {'seasons': seasons, 'poster': poster, 'description': desc}


def _get_episodes(season_id):
    """Get episodes for a season via JSON API."""
    data = _api_get('/series/season/' + str(season_id))
    episodes = []
    series_id = data.get('series_id', '')
    for ep in data.get('episodes', []):
        episodes.append({
            'id': ep.get('id', ''),
            'title': ep.get('title', ''),
        })
    return {'episodes': episodes, 'series_id': series_id}


def _get_episode(episode_id):
    """Get episode data via JSON API. Returns watch_url."""
    data = _api_get('/series/episode/' + str(episode_id))
    episode = data.get('episode', {})
    series = data.get('series', {})
    return {
        'watch_url': episode.get('watch_url', ''),
        'can_watch': episode.get('can_watch', False),
        'reason': episode.get('reason', ''),
        'title': episode.get('title', ''),
        'series_slug': series.get('slug', ''),
    }


# ---------------------------------------------------------------------------
# HTML scraping helpers for catalog pages
# ---------------------------------------------------------------------------

def _scrape_catalog_items(html):
    """
    Scrape items from a StarDima catalog page (latest, series, movies).
    Returns list of (url, title, poster_url) tuples.
    """
    items = []
    item_blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', html)

    for block in item_blocks:
        link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie)/[^"]+)"', block)
        poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
        title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)

        if link_m and title_m:
            url = link_m.group(1)
            if not url.startswith('http'):
                url = 'https://' + url
            title = title_m.group(1).strip()
            poster = poster_m.group(1).strip() if poster_m else ''
            items.append((url, title, poster))

    return items


def _catalog_api_paginated(path, page=1, max_pages=1):
    """
    Fetch a catalog page via StarDima's JSON API (X-Requested-With: XMLHttpRequest).
    Loads multiple API pages (~7 pages of 15 = ~100 items) per call for a smooth
    browsing experience, since the server hardcodes 15 items per page.

    Returns {'items': [(url, title, poster), ...], 'last_page': N, 'current_page': page}
    where last_page is the number of virtual pages (each ~100 items).
    Handles paths with existing query params (e.g. /aflam?language=sub).
    """
    ITEMS_PER_API_PAGE = 15
    VIRTUAL_PAGE_SIZE = 100  # Target ~100 items per page
    API_PAGES_PER_VIRTUAL = max(1, VIRTUAL_PAGE_SIZE // ITEMS_PER_API_PAGE)  # 7 API pages

    def _build_items(videos):
        items = []
        for v in videos:
            v_url = v.get('url', '')
            v_title = v.get('title', '')
            v_poster = _resolve_poster(v.get('poster_url', ''))
            items.append((v_url, v_title, v_poster))
        return items

    def _build_url(pg):
        url = BASEURL + path
        if pg > 1:
            sep = '&' if '?' in path else '?'
            url += sep + 'page=' + str(pg)
        return url

    # First request to get total page count
    first_api_page = (page - 1) * API_PAGES_PER_VIRTUAL + 1
    r = request_helper(_build_url(first_api_page), extra_headers=_API_HEADERS)
    data = r.json()
    pagination = data.get('pagination', {})
    total_api_pages = pagination.get('last_page', 1)

    # Calculate virtual page count
    total_items = total_api_pages * ITEMS_PER_API_PAGE
    virtual_last_page = max(1, (total_items + VIRTUAL_PAGE_SIZE - 1) // VIRTUAL_PAGE_SIZE)

    # Fetch API pages for this virtual page
    items = []
    seen_urls = set()
    for offset in range(API_PAGES_PER_VIRTUAL):
        api_pg = first_api_page + offset
        if api_pg > total_api_pages:
            break
        r2 = request_helper(_build_url(api_pg), extra_headers=_API_HEADERS)
        data2 = r2.json()
        for v in data2.get('videos', []):
            v_url = v.get('url', '')
            if v_url in seen_urls:
                continue
            seen_urls.add(v_url)
            v_title = v.get('title', '')
            v_poster = _resolve_poster(v.get('poster_url', ''))
            items.append((v_url, v_title, v_poster))

    return {'items': items, 'last_page': virtual_last_page, 'current_page': page}


def _scrape_catalog_paginated(path, page=1, max_pages=1):
    """
    Scrape a catalog path. When max_pages=1 (default), returns a single page:
      {'items': [...], 'last_page': N, 'current_page': page}
    When max_pages>1, returns a flat list of items (legacy mode).
    Handles paths with existing query params (e.g. /aflam?language=sub).
    """
    url = BASEURL + path
    if page > 1:
        sep = '&' if '?' in path else '?'
        url += sep + 'page=' + str(page)
    r = request_helper(url)
    html = r.text

    page_items = _scrape_catalog_items(html)

    # Check pagination
    last_page_m = re.search(r'data-last-page="(\d+)"', html)
    last_page = int(last_page_m.group(1)) if last_page_m else 1

    if max_pages == 1:
        return {'items': page_items, 'last_page': last_page, 'current_page': page}

    # Legacy mode: fetch multiple pages
    items = list(page_items)
    seen_urls = {item[0] for item in page_items}
    for pg in range(2, max_pages + 1):
        if pg > last_page:
            break
        url2 = BASEURL + path
        sep = '&' if '?' in path else '?'
        url2 += sep + 'page=' + str(pg)
        r2 = request_helper(url2)
        page_items2 = _scrape_catalog_items(r2.text)
        for item_url, item_title, item_poster in page_items2:
            if item_url not in seen_urls:
                seen_urls.add(item_url)
                items.append((item_url, item_title, item_poster))
    return items


def _scrape_homepage_popular(html):
    """Scrape popular items from the homepage."""
    items = []
    # Popular items on homepage have similar structure
    # Look for movie links in the homepage
    item_blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', html)

    for block in item_blocks:
        link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie)/[^"]+)"', block)
        poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
        title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)

        if link_m and title_m:
            url = link_m.group(1)
            if not url.startswith('http'):
                url = 'https://' + url
            title = title_m.group(1).strip()
            poster = poster_m.group(1).strip() if poster_m else ''
            items.append((url, title, poster))

    return items


def _scrape_newreleases_by_tab():
    """
    Scrape /newrelases page and split into 3 tab sections:
      - NewEpisodes: episodes with /play/ URLs
      - NewMovies: movie items
      - NewSeries: series items
    """
    r = request_helper(BASEURL + '/newrelases')
    html = r.text

    episodes = []
    movies = []
    series = []

    # Split HTML by tab content sections
    ep_section_m = re.search(r'data-content="episodes"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)
    series_section_m = re.search(r'data-content="series"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)
    movies_section_m = re.search(r'data-content="movies"(.*?)(?=<section\s+class="tab-content|<script)', html, re.DOTALL)

    def _extract_items(section_html):
        """Extract items from a tab section's HTML."""
        if not section_html:
            return []
        items = []
        blocks = re.split(r'(?=<div\s+class="[^"]*group/item)', section_html)
        for block in blocks:
            link_m = re.search(r'<a\s+href="((?:https://)?(?:www\.)?stardima\.com/(?:tvshow|movie|play)/[^"]+)"', block)
            poster_m = re.search(r'<img[^>]+src="([^"]+)"', block)
            title_m = re.search(r'<h4[^>]+>[ \t]*([^<]+)[ \t]*</h4>', block)
            if not title_m:
                title_m = re.search(r'<h3[^>]+>[ \t]*([^<]+)[ \t]*</h3>', block)

            if link_m and title_m:
                url = link_m.group(1)
                if not url.startswith('http'):
                    url = 'https://' + url
                title = title_m.group(1).strip()
                poster = poster_m.group(1).strip() if poster_m else ''
                items.append((url, title, poster))
        return items

    episodes = _extract_items(ep_section_m.group(1) if ep_section_m else '')
    movies = _extract_items(movies_section_m.group(1) if movies_section_m else '')
    series = _extract_items(series_section_m.group(1) if series_section_m else '')

    return {
        'NewEpisodes': tuple(episodes),
        'NewMovies': tuple(movies),
        'NewSeries': tuple(series),
    }


# ---------------------------------------------------------------------------
# Stream resolution — full chain from StarDima to playable URL
# ---------------------------------------------------------------------------

def resolve_stardima_stream(url, server_name=None):
    """
    Resolve a StarDima video URL to a playable stream.
    If server_name is provided, only try that specific server.
    """
    import html as html_mod
    import urllib.parse as up
    import xbmc

    log = lambda msg: xbmc.log(f'AraToons: {msg}', xbmc.LOGINFO)
    log(f'resolving: {url} (server={server_name})')

    def _referer(base_url):
        """Extract origin URL for Referer header."""
        p = up.urlparse(base_url)
        return p.scheme + '://' + p.netloc + '/'

    embed_url = None

    # If already a hyperwatching URL, skip StarDima scraping
    if 'hyperwatching' in url:
        embed_url = url
    else:
        # Step 1: Get hyperwatching embed URL from StarDima play page
        r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
        star_html = r.text

        # Handle movie detail pages — redirect to /play/{id}
        if '/movie/' in url and '/play/' not in url:
            movie_id_m = re.search(r'/movie/([^?/]+)', url)
            if movie_id_m:
                url = BASEURL + '/play/' + movie_id_m.group(1)
                r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
                star_html = r.text

        og_m = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
        if og_m:
            og_video = og_m.group(1)
            # Only use og:video if it points to an external embed (hyperwatching)
            if 'hyperwatching' in og_video or 'stardima' not in og_video:
                embed_url = og_video

        if not embed_url:
            # Try iframe src
            iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', star_html)
            if iframe_m:
                embed_url = iframe_m.group(1)

        if not embed_url:
            # Try to find play link on the page and follow it
            play_m = re.search(r'href="((?:https://)?(?:www\.)?stardima\.com/play/[^"]+)"', star_html)
            if play_m:
                play_url = play_m.group(1)
                if not play_url.startswith('http'):
                    play_url = 'https://' + play_url
                r = request_helper(play_url, extra_headers={'Referer': BASEURL + '/'})
                star_html = r.text
                og_m2 = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
                if og_m2:
                    embed_url = og_m2.group(1)

        if not embed_url:
            # Cloudflare blocked the page — try episode API for /play/ URLs
            ep_match = re.search(r'/play/(\d+)$', url)
            if ep_match:
                episode_id = ep_match.group(1)
                ep_data = _get_episode(episode_id)
                watch_url = ep_data.get('watch_url', '')
                if watch_url:
                    embed_url = watch_url

    if not embed_url:
        log('no embed_url found')
        return None

    # Step 2: Fetch hyperwatching page and parse data-page JSON
    r2 = request_helper(embed_url, extra_headers={'Referer': url})
    hw_html = r2.text

    data_page_m = re.search(r'data-page="([^"]+)"', hw_html)
    if not data_page_m:
        return None

    data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
    video = data_page.get('props', {}).get('video', {})
    hashid = video.get('hashid', '')
    servers = video.get('servers', [])

    if not hashid or not servers:
        log(f'no hashid/servers: hashid={hashid}, servers={len(servers)}')
        return None

    # If a specific server is requested, filter to only that one
    if server_name:
        matched = [s for s in servers if s.get('name', '') == server_name and s.get('id', 0) != 0]
        if matched:
            servers = matched
        else:
            log(f'server {server_name} not found')
            return None

    # Step 3: Try all servers — Mixdrop first (direct MP4), then StreamHG (m3u8)
    server_order = []
    priority_servers = []  # [Mixdrop, StreamHG]
    other_servers = []
    for s in servers:
        if s.get('id', 0) == 0:
            continue
        name = s.get('name', '')
        if name in ('Mixdrop', 'Streamhg', 'Uqload', 'Lulustream', 'Earnvids', 'Goodstream'):
            priority_servers.append(s)
        else:
            other_servers.append(s)
    # Order: Mixdrop first, then Uqload, StreamHG, Earnvids, Goodstream
    priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Lulustream': 2, 'Streamhg': 3, 'Earnvids': 4, 'Goodstream': 5}
    priority_servers.sort(key=lambda s: priority_order.get(s.get('name', ''), 99))
    server_order = priority_servers + other_servers

    hw_base = 'https://v2.hyperwatching.com'

    for server in server_order:
        server_id = server.get('id', 0)
        name = server.get('name', '')
        log(f'trying server: {name} (id={server_id})')

        api_url = '{}/embed/{}/server/{}/url'.format(hw_base, hashid, server_id)
        r3 = request_helper(api_url, extra_headers={'Referer': embed_url})
        try:
            api_data = r3.json()
        except Exception:
            continue

        watch_url = api_data.get('watch_url', '')
        if not watch_url:
            log(f'  no watch_url from API')
            continue

        # Step 4: Fetch the embed page and try to extract stream URL
        r4 = request_helper(watch_url, extra_headers={'Referer': embed_url})
        player_html = r4.text
        log(f'  watch_url: {watch_url}')

        # --- Mixdrop: extract MP4 URL from eval() config ---
        if name == 'Mixdrop':
            mp4_url = _extract_mixdrop_url(player_html)
            log(f'  Mixdrop result: {mp4_url}')
            if mp4_url:
                return (mp4_url, _referer(watch_url))

         # --- Direct hgplaycdn.com (StreamHG) ---
        if 'hgplaycdn.com' in watch_url:
            m3u8_url = _extract_streamhg_url(player_html)
            log(f'  StreamHG direct result: {m3u8_url}')
            if m3u8_url:
                # Clean URL and activate TLS token
                m3u8_url = _clean_jwplayer_url(m3u8_url)
                # Activate TLS token
                import urllib.request as _ur
                import ssl as _ssl
                try:
                    _ctx = _ssl.create_default_context()
                    _ctx.check_hostname = False
                    _ctx.verify_mode = _ssl.CERT_NONE
                    _req = _ur.Request(m3u8_url, headers={
                        'User-Agent': WNT2_USER_AGENT,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-us,en;q=0.5',
                        'Sec-Fetch-Mode': 'navigate',
                    })
                    _resp = _ur.urlopen(_req, timeout=15, context=_ctx)
                    _resp.read()
                except Exception:
                    pass
                # Keep master.m3u8 — Kodi default player handles audio group switching
                return (m3u8_url, {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Sec-Fetch-Mode': 'navigate',
                })
            log(f'  StreamHG extraction failed, trying next server')
            continue

        # --- Filemoon: try to extract m3u8 from the page ---
        if 'filemoon' in watch_url or 'filemoon' in player_html:
            fm_url = _extract_filemoon_url(watch_url, player_html, embed_url)
            log(f'  Filemoon result: {fm_url}')
            if fm_url:
                return (fm_url, _referer(watch_url))

        # --- Earnvids (minochinos.com): eval-encoded JWPlayer ---
        if 'minochinos.com' in watch_url or 'earnvids' in watch_url or 'earnvids' in player_html:
            ev_url = _extract_earnvids_url(player_html)
            log(f'  Earnvids result: {ev_url}')
            if ev_url:
                # Clean URL and activate TLS token
                ev_url = _clean_jwplayer_url(ev_url)
                # Activate TLS token
                import urllib.request as _ur
                import ssl as _ssl
                try:
                    _ctx = _ssl.create_default_context()
                    _ctx.check_hostname = False
                    _ctx.verify_mode = _ssl.CERT_NONE
                    _req = _ur.Request(ev_url, headers={
                        'User-Agent': WNT2_USER_AGENT,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-us,en;q=0.5',
                        'Sec-Fetch-Mode': 'navigate',
                    })
                    _resp = _ur.urlopen(_req, timeout=15, context=_ctx)
                    _resp.read()
                except Exception:
                    pass
                # Keep master.m3u8 — Kodi default player handles audio group switching
                return (ev_url, {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Sec-Fetch-Mode': 'navigate',
                })

        # --- All servers: try to extract m3u8/MP4 from page ---
        m3u8_m = re.search(r'src="([^"]*\.m3u8[^"]*)"', player_html)
        if m3u8_m:
            return (m3u8_m.group(1), _referer(watch_url))

        src_m = re.search(r'<source[^>]+src="([^"]+)"', player_html)
        if src_m:
            return (src_m.group(1), _referer(watch_url))

        data_src_m = re.search(r'data-(?:src|url)="([^"]*\.m3u8[^"]*)"', player_html)
        if data_src_m:
            return (data_src_m.group(1), _referer(watch_url))

        # --- Strema.top proxy: follow POST redirect, then extract stream ---
        if 'strema.top' in watch_url:
            import urllib.parse as up
            parsed = up.urlparse(watch_url)
            params = up.parse_qs(parsed.query)
            if 'id' in params:
                actual_url = up.unquote(params['id'][0])

                # strema.top now uses a two-step flow:
                # 1. GET embed2/ returns a form with POST action URL
                # 2. POST to embed/ with referer returns the actual player page
                # We follow this flow to get the player HTML, then also try
                # fetching the actual embed URL directly as a fallback.
                strema_player_html = _follow_strema_redirect(watch_url, embed_url)
                log(f'  strema POST response: {len(strema_player_html) if strema_player_html else 0} bytes')

                # Also try fetching the actual embed page directly
                r5 = request_helper(actual_url, extra_headers={'Referer': watch_url})
                actual_html = r5.text
                log(f'  actual_url: {actual_url} (html={len(actual_html)} bytes)')

                # Determine if actual_html is a valid player page or an error
                has_video_content = ('<video' in actual_html or '<source' in actual_html)
                has_jwplayer = 'eval(function(p,a,c,k,e,d)' in actual_html
                strema_has_error = (not has_video_content and not has_jwplayer and (
                    'not found' in actual_html.lower() or
                    'file has been deleted' in actual_html.lower() or
                    ('challenge' in actual_html.lower() and 'cloudflare' in actual_html.lower()) or
                    len(actual_html) < 200))
                log(f'  strema_has_error: {strema_has_error}')

                # --- StreamHG (hgplaycdn.com) ---
                if 'hgplaycdn.com' in actual_url:
                    m3u8_url = _extract_streamhg_url(actual_html)
                    log(f'  StreamHG (via strema) result: {m3u8_url}')
                    if m3u8_url:
                        m3u8_url = _clean_jwplayer_url(m3u8_url)
                        # Activate TLS token
                        import urllib.request as _ur
                        import ssl as _ssl
                        try:
                            _ctx = _ssl.create_default_context()
                            _ctx.check_hostname = False
                            _ctx.verify_mode = _ssl.CERT_NONE
                            _req = _ur.Request(m3u8_url, headers={
                                'User-Agent': WNT2_USER_AGENT,
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-us,en;q=0.5',
                                'Sec-Fetch-Mode': 'navigate',
                            })
                            _resp = _ur.urlopen(_req, timeout=15, context=_ctx)
                            _resp.read()
                        except Exception:
                            pass
                        # Keep master.m3u8 — Kodi default player handles audio group switching
                        return (m3u8_url, {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-us,en;q=0.5',
                            'Sec-Fetch-Mode': 'navigate',
                        })
                    log(f'  StreamHG (via strema) extraction failed, trying next server')
                    continue

                # --- Goodstream: resolve via direct embed URL extraction ---
                if 'goodstream' in actual_url:
                    # Extract actual Goodstream embed URL from strema embed2, then fetch it directly
                    gs_url = _resolve_strema_stream(watch_url, embed_url)
                    log(f'  Goodstream strema resolve result: {gs_url}')
                    if gs_url:
                        # Goodstream CDN validates Accept header + TLS fingerprint.
                        # Token activated by urllib m3u8 fetch above. Return headers
                        # dict so ffmpegdirect uses browser-like Accept header.
                        return (gs_url, {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-us,en;q=0.5',
                            'Sec-Fetch-Mode': 'navigate',
                        })

                    # Fallback: try direct page extraction (old method)
                    gs_url = _extract_goodstream_url(actual_html)
                    log(f'  Goodstream direct result: {gs_url}')
                    if gs_url:
                        gs_url = _clean_jwplayer_url(gs_url)
                        log(f'  Goodstream cleaned: {gs_url}')
                        return (gs_url, _referer(actual_url))

                    # Try strema POST response (katana-obfuscated, try JWPlayer decoder)
                    if strema_player_html:
                        gs_url2 = _extract_goodstream_url(strema_player_html)
                        if not gs_url2:
                            gs_url2 = _extract_jwplayer_url(strema_player_html)
                        log(f'  Goodstream strema POST result: {gs_url2}')
                        if gs_url2:
                            gs_url2 = _clean_jwplayer_url(gs_url2)
                            log(f'  Goodstream cleaned: {gs_url2}')
                            return (gs_url2, _referer(actual_url))

                    log(f'  Goodstream extraction failed, trying next server')
                    continue

                # --- All JWPlayer servers via strema: resolve with audio detection ---
                # _resolve_strema_stream handles Goodstream, Lulustream, Uqload,
                # StreamHG, and Earnvids — direct embed fetch, audio dialog, TLS activation
                if ('goodstream' in actual_url or
                    'lulustream' in actual_url or 'lulucdn' in actual_url or
                    'tnmr.org' in actual_url or 'luluvdo' in actual_url or
                    'uqload.is' in actual_url):
                    strema_resolved = _resolve_strema_stream(watch_url, embed_url)
                    log(f'  strema resolve result: {strema_resolved}')
                    if strema_resolved:
                        return strema_resolved

                # Prefer actual_html (direct fetch) if valid, otherwise strema POST
                jw_source_html = actual_html if not strema_has_error else player_html
                # If both direct and player_html failed, try strema POST
                if strema_has_error and strema_player_html:
                    jw_url_direct = _extract_jwplayer_url(actual_html)
                    jw_url_strema = _extract_jwplayer_url(strema_player_html)
                    jw_url = jw_url_direct or jw_url_strema
                    jw_source_html = actual_html if jw_url_direct else strema_player_html
                else:
                    jw_url = _extract_jwplayer_url(jw_source_html)

                log(f'  JWPlayer result: {jw_url}')
                if jw_url:
                    jw_url = _clean_jwplayer_url(jw_url)
                    log(f'  JWPlayer cleaned: {jw_url}')
                    referer = _referer(actual_url if not strema_has_error else watch_url)
                    cookie = _extract_jwplayer_cookies(jw_source_html)
                    if cookie:
                        log(f'  JWPlayer cookies: {cookie}')
                    verified = _verify_stream_url(jw_url, referer, cookie)
                    if verified:
                        return (jw_url, referer)
                    log(f'  JWPlayer URL not accessible, trying next server')
                    continue

    log('no playable stream found')
    return None


def get_stardima_servers(url):
    """Return list of available servers for a given URL."""
    import html as html_mod
    r = request_helper(url, extra_headers={'Referer': BASEURL + '/'})
    star_html = r.text
    og_m = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
    og_video = og_m.group(1) if og_m else ''
    embed_url = ''
    if og_video:
        if 'hyperwatching' in og_video or 'stardima' not in og_video:
            embed_url = og_video
    if not embed_url:
        iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', star_html)
        if iframe_m:
            embed_url = iframe_m.group(1)
    if not embed_url:
        play_m = re.search(r'href="((?:https://)?(?:www\.)?stardima\.com/play/[^"]+)"', star_html)
        if play_m:
            play_url = play_m.group(1)
            if not play_url.startswith('http'):
                play_url = 'https://' + play_url
            r = request_helper(play_url, extra_headers={'Referer': BASEURL + '/'})
            star_html = r.text
            og_m2 = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', star_html)
            if og_m2:
                embed_url = og_m2.group(1)
    if not embed_url:
        ep_match = re.search(r'/play/(\d+)$', url)
        if ep_match:
            ep_data = _get_episode(ep_match.group(1))
            watch_url = ep_data.get('watch_url', '')
            if watch_url:
                embed_url = watch_url
    if not embed_url:
        return []
    r2 = request_helper(embed_url, extra_headers={'Referer': url})
    data_page_m = re.search(r'data-page="([^"]+)"', r2.text)
    if not data_page_m:
        return []
    data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
    servers = data_page.get('props', {}).get('video', {}).get('servers', [])
    priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Lulustream': 2, 'Streamhg': 3, 'Earnvids': 4, 'Goodstream': 5}
    result = []
    for s in servers:
        if s.get('id', 0) == 0:
            continue
        name = s.get('name', '')
        status = s.get('status', '')
        label = name + (' (ready)' if status == 'completed' else ' (processing)')
        result.append({'name': name, 'label': label, 'priority': priority_order.get(name, 99)})
    result.sort(key=lambda s: s['priority'])
    return result


def _verify_stream_url(url, referer, cookie=None):
    """Quick GET request to verify a stream URL returns valid content."""
    import urllib.request
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0',
        'Referer': referer,
        'Origin': referer.rsplit('/', 1)[0],
    }
    if cookie:
        headers['Cookie'] = cookie
    req = urllib.request.Request(url, method='GET', headers=headers)
    try:
        import ssl as _ssl
        _ctx = _ssl.create_default_context()
        _ctx.check_hostname = False
        _ctx.verify_mode = _ssl.CERT_NONE
        resp = urllib.request.urlopen(req, timeout=5, context=_ctx)
        if resp.status != 200:
            return False
        # Verify actual content is valid (m3u8 or mp4)
        data = resp.read(200)
        content_type = resp.headers.get('content-type', '')
        if 'm3u8' in url or 'mpegurl' in content_type:
            return b'#EXTM3U' in data
        elif 'mp4' in url or 'octet-stream' in content_type or 'mp4' in content_type:
            return len(data) > 100
        return len(data) > 50
    except Exception:
        return False


def _to_base36(n):
    """Convert integer to base-36 string (same as JS c.toString(36))."""
    if n == 0:
        return '0'
    chars = '0123456789abcdefghijklmnopqrstuvwxyz'
    result = ''
    while n > 0:
        result = chars[n % 36] + result
        n //= 36
    return result


def _extract_mixdrop_url(html):
    """Extract direct MP4 URL from Mixdrop embed page eval() config.

    Mixdrop uses eval with e=function(c){return c} (identity, NOT base-36).
    The keyword tokens are just the decimal index number.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    # Check whether it's Mixdrop identity decoder or base-36
    chunk = html[pos:pos+300]
    is_identity = 'return c}' in chunk and 'toString' not in chunk

    # Find the encoded string start - Mixdrop uses }(' while others use }('
    enc_start = html.find("}('", pos)
    if enc_start < 0:
        return None
    enc_start += 3  # Skip }('

    rest = html[enc_start:]
    # Find the end: encoded_string',base,count,'keywords
    # Look for the split marker
    split_marker = "'.split('|'),0,{}))"
    split_pos = rest.find(split_marker)
    if split_pos < 0:
        return None

    # Extract call args
    call_args = rest[:split_pos]
    # Find: encoded_string',base,count,'keywords
    close_m = re.search(r"',(\d+),(\d+),'(.*)$", call_args)
    if not close_m:
        return None

    encoded = call_args[:close_m.start()]
    count = int(close_m.group(2))
    keywords = close_m.group(3).split('|')

    # Decode - Mixdrop uses identity (decimal), others use base-36
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if i >= len(keywords) or not keywords[i]:
            continue
        token = str(i) if is_identity else _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(token) + r'(?!\w)', re.escape(keywords[i]), decoded)

    wurl_m = re.search(r'wurl["\']?\s*=\s*"([^"]+\.mp4[^"]*)"', decoded)
    if wurl_m:
        mp4 = wurl_m.group(1)
        if not mp4.startswith('http'):
            mp4 = 'https:' + mp4 if mp4.startswith('//') else 'https://' + mp4
        return mp4

    furl_m = re.search(r'furl["\']?\s*=\s*"([^"]+\.mp4[^"]*)"', decoded)
    if furl_m:
        mp4 = furl_m.group(1)
        if not mp4.startswith('http'):
            mp4 = 'https:' + mp4 if mp4.startswith('//') else 'https://' + mp4
        return mp4

    return None


def _extract_jwplayer_url(html):
    """Extract stream URL from JWPlayer eval() config.

    The eval function uses c.toString(36) (base-36) not hex.
    Skips empty keywords (like eval's if(k[c])).
    Returns plain string URL (same as streamhg branch).
    """
    pos = html.find('eval(function(p,a,c,k,e,d){while(c--)')
    if pos < 0:
        pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        return None
    enc_start += len("return p}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    count = int(close_m.group(2))
    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None

    keywords = after[:split_pos].split('|')

    # Decode using base-36 (same as eval's c.toString(36))
    # Process descending, skip empty keywords (like eval's if(k[c]))
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', re.escape(keywords[i]), decoded)

    # Find m3u8 or mp4 URL in decoded config
    m3u8_m = re.search(r'(https?://[^"\'\\]+\.m3u8[^"\'\\]*)', decoded)
    if m3u8_m:
        url = m3u8_m.group(1)
        return url

    mp4_m = re.search(r'(https?://[^"\'\\]+\.mp4[^"\'\\]*)', decoded)
    if mp4_m:
        return mp4_m.group(1)

    return None


def _clean_jwplayer_url(url):
    """Clean JWPlayer URLs that have empty-keyword artifacts in the path.

    Handles two formats:
    1) Uqload/Goodstream: /FILE_ID_,tok1,tok2,tok3,.garbage/master.m3u8
       -> /FILE_ID_tok2/master.m3u8
    2) Lulustream (new): /BASE/,FILE_ID_quality,lang/...,,.urlset/master.m3u8
       -> /BASE/FILE_ID_quality/index-v1-a2.m3u8
    """
    # Format 2: Lulustream with /,FILE_ID_quality,garbage,.urlset/
    m = re.search(r'(https://[^/]+/hls2/[^/]+/[^/]+/),(\w+)_(\w+).*?(?:master|index-v1-a\d)\.m3u8', url)
    if m:
        base = m.group(1)
        file_id = m.group(2)
        quality = m.group(3)
        query_start = url.find('?')
        query = url[query_start:] if query_start >= 0 else ''
        return f"{base}{file_id}_{quality}/index-v1-a2.m3u8{query}"

    # Format 1: Uqload/Goodstream /FILE_ID_,tok1,tok2,tok3,.garbage/
    m = re.search(r'(/[^,]+_),([^,]+),([^,]+),([^,]+),\.[^/]*/(master|index-v1-a1)', url)
    if m:
        base_path = m.group(1)
        quality = m.group(3)
        playlist = m.group(5)
        url = url.replace(m.group(0), f'{base_path}{quality}/{playlist}')

    return url


def _extract_jwplayer_cookies(html):
    """Extract $.cookie() values from JWPlayer page for Uqload."""
    cookies = []
    for m in re.finditer(r"\.cookie\(['\"]([^'\"]+)['\"],\s*['\"]([^'\"]+)['\"]", html):
        cookies.append(f'{m.group(1)}={m.group(2)}')
    return '; '.join(cookies) if cookies else ''


def _extract_streamhg_url(html):
    """Extract m3u8 URL from StreamHG (hgplaycdn.com) eval config.

    Uses base-36 decoding like _extract_jwplayer_url.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        return None
    enc_start += len("return p}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    count = int(close_m.group(2))
    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None
    keywords = after[:split_pos].split('|')

    # Decode using base-36 (same as eval's c.toString(36))
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', re.escape(keywords[i]), decoded)

    # Find the m3u8 URL - prefer .m3u8 (with query params) over .txt (bare)
    for m in re.finditer(r'(https?://[^\s"\'`<>,;]{30,})', decoded):
        url = m.group(1).rstrip('",;')
        if 'master' in url and '.m3u8' in url:
            return url

    for m in re.finditer(r'(https?://[^\s"\'`<>,;]{30,})', decoded):
        url = m.group(1).rstrip('",;')
        if 'master' in url and '.txt' in url:
            return url

    return None


def _extract_filemoon_url(watch_url, player_html, embed_url):
    """Extract m3u8 URL from Filemoon embed page.

    Filemoon uses an iframe on a subdomain (e.g. q8y5z.com).
    We fetch the iframe page and try to extract the stream URL
    from JWPlayer config or direct src attributes.

    Note: Filemoon uses ECDSA signing + PoW captcha + AES-GCM
    encryption for the API flow. This is too complex for the
    addon environment. We fall back to extracting from page HTML.
    """
    # Look for iframe src in the Filemoon page
    iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', player_html)
    if not iframe_m:
        return None

    iframe_url = iframe_m.group(1)
    if not iframe_url.startswith('http'):
        iframe_url = 'https:' + iframe_url if iframe_url.startswith('//') else 'https://' + iframe_url

    # Fetch the iframe page
    try:
        r = request_helper(iframe_url, extra_headers={'Referer': watch_url})
        iframe_html = r.text
    except Exception:
        return None

    # Try to find m3u8 URL directly in the iframe HTML
    m3u8_m = re.search(r'(https?://[^"\'\s]+master[^"\'\s]*\.m3u8[^"\'\s]*)', iframe_html)
    if m3u8_m:
        return m3u8_m.group(1)

    # Try JWPlayer eval decoder
    jw_result = _extract_jwplayer_url(iframe_html)
    if jw_result:
        return jw_result

    # Try to find any m3u8 URL in the page
    for m in re.finditer(r'(https?://[^"\'\s]{30,})', iframe_html):
        url = m.group(1).rstrip('",;')
        if '.m3u8' in url or '.txt' in url:
            return url

    return None


def _follow_strema_redirect(strema_url, referer_url):
    """Follow strema.top's POST redirect to get the actual player page.

    strema.top uses a two-step flow:
    1. GET embed2/?id=... returns an HTML form with POST action URL
    2. POST to embed/?TOKEN with referer field returns the player page

    Returns player HTML string or None on failure.
    """
    import urllib.parse as up

    try:
        # Step 1: GET the strema.top embed2 URL
        r = request_helper(strema_url, extra_headers={'Referer': referer_url})
        strema_html = r.text

        # Extract the form action URL (POST target)
        action_m = re.search(r'action="([^"]+)"', strema_html)
        if not action_m:
            return None

        post_url = action_m.group(1)

        # Step 2: POST with referer
        post_data = up.urlencode({'referer': referer_url}).encode()
        post_headers = {
            'Referer': strema_url,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://strema.top',
        }
        r2 = request_helper(post_url, data=post_data, extra_headers=post_headers)
        return r2.text
    except Exception:
        return None


def _resolve_stream_audio(final_url, embed_html):
    """Inspect master.m3u8 to determine available audio tracks.

    Works for all JWPlayer servers (Uqload, StreamHG, Earnvids, Goodstream, Lulustream):
    - Multi-audio (eng+ara separate tracks): show dialog, return (url, headers)
    - Single-audio (only a1 or only a2 separate): return correct track
    - Muxed audio (no separate tracks): return muxed stream (a1)
    - Returns None on error so caller uses default

    Returns (url, headers_dict) on success, None to let caller proceed.
    """
    import urllib.request, ssl as _ssl

    # Only act on known multi-audio servers
    is_uqload = 'uqload.is' in final_url
    is_streamhg = 'premilkyway.com' in final_url
    is_earnvids = 'acek-cdn.com' in final_url
    is_lulu = 'tnmr.org' in final_url or 'lulucdn' in final_url
    is_gs = 'goodstream' in final_url
    if not (is_uqload or is_streamhg or is_earnvids or is_lulu or is_gs):
        return None

    # Extract base path and query from URL
    base_m = re.search(r'(https://[^/]+/hls2/[^/]+/[^/]+/\w+_\w+)/', final_url)
    if not base_m:
        return None

    base_path = base_m.group(1)
    query_start = final_url.find('?')
    query = final_url[query_start:] if query_start >= 0 else ''

    # Fetch master.m3u8 to detect audio tracks
    master_url = f"{base_path}/master.m3u8{query}"
    ctx = _ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = _ssl.CERT_NONE

    try:
        req = urllib.request.Request(master_url, headers={
            'User-Agent': WNT2_USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-us,en;q=0.5',
            'Sec-Fetch-Mode': 'navigate',
            'Referer': embed_html if isinstance(embed_html, str) and embed_html.startswith('http') else '',
        })
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        master = resp.read().decode('utf-8', errors='replace')
    except Exception:
        return None

    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-us,en;q=0.5',
        'Sec-Fetch-Mode': 'navigate',
    }

    # Parse audio tracks from master playlist
    # Uqload uses full URLs; others use relative paths
    audio_tracks = {}
    for line in master.split('\n'):
        if '#EXT-X-MEDIA:TYPE=AUDIO' in line:
            # Extract NAME and URI
            name_m = re.search(r'NAME="([^"]+)"', line)
            uri_m = re.search(r'URI="([^"]+)"', line)
            if name_m and uri_m:
                name = name_m.group(1)
                uri = uri_m.group(1)
                # Extract audio track number (a1, a2, a3)
                track_m = re.search(r'index-(a\d+)\.m3u8', uri)
                if track_m:
                    audio_tracks[track_m.group(1)] = name

    # All servers: return None to skip audio dialog.
    # The caller returns master.m3u8 so Kodi's default player handles
    # audio group switching via the native audio track button.
    return None


def _decode_jwplayer_eval(html):
    """Decode katana eval-encoded JWPlayer config (Lulustream).

    Returns the decoded JavaScript string or None if not found.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        enc_start = html.find("}('", pos)
    if enc_start < 0:
        return None

    if "return p}('" in html[enc_start-10:enc_start+10]:
        enc_start += len("return p>('")
    else:
        enc_start += len("}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    count = int(close_m.group(2))

    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None

    keywords = after[:split_pos].split('|')

    decoded = encoded
    for i in range(count - 1, -1, -1):
        if i >= len(keywords) or not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', keywords[i], decoded)

    return decoded


def _resolve_strema_stream(strema_url, referer_url):
    """Resolve strema.top proxy to actual stream URL.

    The strema.top embed2 URL contains the actual embed URL in its 'id' parameter.
    Instead of going through strema's obfuscated player, we extract the actual
    embed URL and fetch it directly. All JWPlayer servers serve the m3u8 URL
    in plain or eval-encoded JWPlayer config on their own pages.

    Returns (final_m3u8_url, headers_dict) for most servers,
    or plain URL string for Goodstream. Returns None on failure.
    """
    import urllib.parse as up
    import urllib.request
    import urllib.error

    try:
        # Step 1: Parse the embed2 URL to extract the 'id' parameter (actual embed URL)
        parsed = up.urlparse(strema_url)
        params = up.parse_qs(parsed.query)
        if 'id' not in params:
            return None
        actual_embed = up.unquote(params['id'][0])

        # Determine which server this is
        is_goodstream = 'goodstream' in actual_embed
        is_lulustream = 'lulustream' in actual_embed or 'lulucdn' in actual_embed or 'tnmr.org' in actual_embed or 'luluvdo' in actual_embed
        is_uqload = 'uqload.is' in actual_embed
        is_streamhg = 'hgplaycdn.com' in actual_embed
        is_earnvids = 'minochinos.com' in actual_embed

        # Step 2: Fetch the actual embed page
        # Use Chrome UA + no Referer + Sec-Fetch-Mode to match browser behavior.
        # CDN generates stream tokens tied to the request pattern.
        req = urllib.request.Request(actual_embed, headers={
            'User-Agent': WNT2_USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-us,en;q=0.5',
            'Sec-Fetch-Mode': 'navigate',
        })
        try:
            import ssl as _ssl
            _ctx = _ssl.create_default_context()
            _ctx.check_hostname = False
            _ctx.verify_mode = _ssl.CERT_NONE
            resp = urllib.request.urlopen(req, timeout=10, context=_ctx)
            embed_html = resp.read().decode('utf-8', errors='replace')
        except (urllib.error.HTTPError, Exception):
            return None

        # Step 3: Extract the m3u8 URL from JWPlayer sources config
        m3u8_m = re.search(r'sources:\s*\[\s*\{\s*file\s*:\s*"([^"]+\.m3u8[^"]*)"', embed_html)
        if not m3u8_m:
            # Try alternative pattern
            m3u8_m = re.search(r'"file"\s*:\s*"([^"]+\.m3u8[^"]*)"', embed_html)
        if not m3u8_m:
            # Try eval-encoded JWPlayer (Lulustream/Uqload katana obfuscation)
            decoded = _decode_jwplayer_eval(embed_html)
            if decoded:
                m3u8_m = re.search(r'sources:\s*\[\s*\{\s*file\s*:\s*"([^"]+\.m3u8[^"]*)"', decoded)
                if not m3u8_m:
                    m3u8_m = re.search(r'"file"\s*:\s*"([^"]+\.m3u8[^"]*)"', decoded)
                if not m3u8_m:
                    m3u8_m = re.search(r'(https?://[^\s"\x27`<>,;]{30,})', decoded)
                    if m3u8_m and 'm3u8' not in m3u8_m.group(1):
                        m3u8_m = None
        if not m3u8_m:
            return None

        final_url = m3u8_m.group(1)

        # Clean JWPlayer URL artifacts (e.g., ,l,n,h,.urlset)
        final_url = _clean_jwplayer_url(final_url)

        # Build Referer for CDN — Lulustream/tnmr.org requires the embed page URL
        # as Referer or it returns 403. Other servers are less strict.
        cdn_referer = actual_embed if actual_embed.startswith('http') else ''

        # Critical: fetch the m3u8 playlist with urllib (OpenSSL) to "activate"
        # the token. CDN uses TLS fingerprinting — it accepts connections from
        # OpenSSL (Python urllib) but rejects gnutls (ffmpeg, curl, Kodi's player).
        # By fetching the m3u8 first with urllib, the CDN marks the token as valid,
        # and subsequent gnutls connections from the same IP are allowed through.
        try:
            m3u8_req = urllib.request.Request(final_url, headers={
                'User-Agent': WNT2_USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-us,en;q=0.5',
                'Sec-Fetch-Mode': 'navigate',
                'Referer': cdn_referer,
            })
            import ssl as _ssl
            _ctx = _ssl.create_default_context()
            _ctx.check_hostname = False
            _ctx.verify_mode = _ssl.CERT_NONE
            m3u8_resp = urllib.request.urlopen(m3u8_req, timeout=15, context=_ctx)
            m3u8_resp.read()  # Read and discard — we just need the connection
        except Exception:
            pass  # Continue anyway — the URL might still work

        # Check audio tracks (works for all servers)
        audio_result = _resolve_stream_audio(final_url, actual_embed)
        if audio_result:
            audio_url, audio_headers = audio_result
            # Goodstream returns plain URL; others return (url, headers) tuple
            if is_goodstream:
                return audio_url
            return (audio_url, audio_headers)

        # Audio dialog skipped — return master.m3u8 so Kodi's default player
        # handles audio group switching via the native audio track button.
        # master.m3u8 contains #EXT-X-MEDIA audio group + #EXT-X-STREAM-INF variants.
        pass

        # Return with headers for non-Goodstream, plain URL for Goodstream
        if is_goodstream:
            return final_url

        return (final_url, {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-us,en;q=0.5',
            'Sec-Fetch-Mode': 'navigate',
            'Referer': cdn_referer,
        })

    except Exception:
        return None


def _extract_goodstream_url(html):
    """Extract m3u8 URL from Goodstream JWPlayer config.

    Goodstream has the URL in plain text inside jwplayer().setup({sources:...}).

    The master.m3u8 playlist is a multi-level index that takes time to resolve
    (even when cleaned to a single variant). Replace it with index-v1-a1.m3u8
    which is the direct media playlist that plays immediately.

    NOTE: index-v1-a1.m3u8 is a media playlist (no #EXT-X-STREAM-INF),
    so it must be played with Kodi's default player / ffmpegdirect,
    NOT inputstream.adaptive.
    """
    # Find jwplayer setup with sources containing the m3u8 URL
    m = re.search(r'sources:\s*\[\s*\{\s*file:\s*["\x27]([^"\x27]+\.m3u8[^"\x27]*)["\x27]', html)
    if m:
        url = m.group(1)
        return url

    # Fallback: find any .m3u8 URL in the page
    m = re.search(r'(https?://[^\x27"\s]+\.m3u8[^\x27"\s]*)', html)
    if m:
        url = m.group(1)
        return url

    return None


def _extract_lulustream_url(html):
    """Extract m3u8 URL from Lulustream eval-encoded JWPlayer config.

    Lulustream uses katana obfuscation + base-36 eval decoder.
    The eval block decodes to JWPlayer setup with sources containing the m3u8 URL.

    The master.m3u8 playlist is a multi-level index that takes time to resolve.
    Replace it with index-v1-a1.m3u8 which is the direct media playlist that
    plays immediately.

    NOTE: index-v1-a1.m3u8 is a media playlist (no #EXT-X-STREAM-INF),
    so it must be played with Kodi's default player / ffmpegdirect,
    NOT inputstream.adaptive.
    """
    pos = html.find('eval(function(p,a,c,k,e,d)')
    if pos < 0:
        return None

    enc_start = html.find("return p}('", pos)
    if enc_start < 0:
        enc_start = html.find("}('", pos)
    if enc_start < 0:
        return None

    # Handle both "return p}('" and "}('" variants
    if "return p}('" in html[enc_start-10:enc_start+10]:
        enc_start += len("return p}('")
    else:
        enc_start += len("}('")

    rest = html[enc_start:]
    close_m = re.search(r"',(\d+),(\d+),'", rest)
    if not close_m:
        return None

    encoded = rest[:close_m.start()]
    base = int(close_m.group(1))
    count = int(close_m.group(2))

    after = rest[close_m.end():]
    split_pos = after.find("'.split('|')")
    if split_pos < 0:
        return None

    keywords = after[:split_pos].split('|')

    # Decode using base-36
    decoded = encoded
    for i in range(count - 1, -1, -1):
        if not keywords[i]:
            continue
        b36 = _to_base36(i)
        decoded = re.sub(r'(?<!\w)' + re.escape(b36) + r'(?!\w)', re.escape(keywords[i]), decoded)

    # Find m3u8 URL
    m3u8_m = re.search(r'(https?://[^\s"\x27`<>,;]{30,})', decoded)
    if m3u8_m:
        url = m3u8_m.group(1).rstrip('";,')
        if 'm3u8' in url:
            return url

    return None


def _extract_earnvids_url(html):
    """Extract m3u8 URL from Earnvids eval-encoded JWPlayer config.

    Earnvids uses eval(function(p,a,c,k,e,d)...) with base-36 decoding,
    same as the existing JWPlayer decoder.

    Always return a media playlist (index-v1-aX.m3u8), never master.m3u8,
    because Kodi's default player can't parse variant playlists.

    For dual-audio videos: show popup to choose Arabic/English.
    For single-audio videos: return index-v1-a1.m3u8 (the only track).

    The master.m3u8 fetch also serves as TLS token activation (OpenSSL
    warms the token so the CDN accepts the subsequent gnutls connection).

    NOTE: Earnvids audio tracks: a1=English, a2=Arabic.
    """
    result = _extract_jwplayer_url(html)
    if result and 'master.m3u8' in result:
        # Fetch master.m3u8 — this activates the TLS token AND checks audio tracks
        import urllib.request
        import ssl as _ssl
        try:
            _ctx = _ssl.create_default_context()
            _ctx.check_hostname = False
            _ctx.verify_mode = _ssl.CERT_NONE
            _req = urllib.request.Request(result, headers={
                'User-Agent': WNT2_USER_AGENT,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-us,en;q=0.5',
                'Sec-Fetch-Mode': 'navigate',
            })
            _resp = urllib.request.urlopen(_req, timeout=10, context=_ctx)
            _master = _resp.read().decode('utf-8', errors='replace')
            audio_count = _master.count('TYPE=AUDIO')
            if audio_count >= 2:
                # Dual audio: show popup
                import xbmcgui
                dialog = xbmcgui.Dialog()
                choice = dialog.select('Select Audio Track', ['Arabic (العربية)', 'English'])
                if choice == 0:
                    result = result.replace('master.m3u8', 'index-v1-a2.m3u8')
                elif choice == 1:
                    result = result.replace('master.m3u8', 'index-v1-a1.m3u8')
                else:
                    result = result.replace('master.m3u8', 'index-v1-a2.m3u8')
            else:
                # Single audio: use index-v1-a1 (the only track)
                result = result.replace('master.m3u8', 'index-v1-a1.m3u8')
        except Exception:
            # If fetch fails, still replace master with index-v1-a1
            result = result.replace('master.m3u8', 'index-v1-a1.m3u8')
    return result
