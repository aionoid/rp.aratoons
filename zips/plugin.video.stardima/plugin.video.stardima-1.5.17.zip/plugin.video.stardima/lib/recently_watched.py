# -*- coding: utf-8 -*-

import os
import time
import json

from lib.common import ensure_path_exists, translate_path
from lib.constants import RESOURCE_URL

MAX_ITEMS = 50


def _data_path():
    return translate_path(RESOURCE_URL + 'data/recently_watched.json')


def _ensure_dir():
    ensure_path_exists(translate_path(RESOURCE_URL + 'data'))


def recently_watched_load():
    """Load recently watched list. Returns list of {name, url, poster, ts} dicts."""
    fp = _data_path()
    if os.path.exists(fp):
        try:
            with open(fp, 'r', encoding='utf8') as f:
                return json.load(f)
        except Exception:
            pass
    return []


def recently_watched_save(items):
    _ensure_dir()
    with open(_data_path(), 'w', encoding='utf8') as f:
        json.dump(items, f, ensure_ascii=False)


def recently_watched_add(name, url, poster=''):
    """Add or update an item. Moves it to the front of the list."""
    items = recently_watched_load()
    # Remove if already exists
    items = [i for i in items if not (i.get('name') == name and i.get('url') == url)]
    # Add to front
    items.insert(0, {
        'name': name,
        'url': url,
        'poster': poster,
        'ts': time.time(),
    })
    # Keep only MAX_ITEMS
    items = items[:MAX_ITEMS]
    recently_watched_save(items)


def recently_watched_remove(index):
    """Remove item by list index."""
    items = recently_watched_load()
    if 0 <= index < len(items):
        items.pop(index)
        recently_watched_save(items)
        return True
    return False
