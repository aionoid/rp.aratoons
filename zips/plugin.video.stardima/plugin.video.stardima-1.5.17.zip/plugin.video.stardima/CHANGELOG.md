# Changelog

## [1.5.17] - 2026-07-31

### Added
- Recently Watched menu on home screen — tracks movies/episodes you play, shows title and poster, up to 50 items with context menu to remove entries

## [1.5.16] - 2026-07-31

### Fixed
- Playback: Lulustream (tnmr.org CDN) now includes `Referer` header in TLS token activation fetch and returned stream headers — CDN requires the embed page URL as Referer or returns 403 Forbidden

## [1.5.15] - 2026-07-29

### Added
- Playback: All JWPlayer servers (Uqload, StreamHG, Earnvids, Goodstream, Lulustream) now use Kodi's default player with inline headers for reliable playback and native audio track switching
- Playback: Earnvids single-audio videos now play correctly (returns media playlist instead of variant playlist)
- Playback: Earnvids dual-audio videos show Arabic/English selection popup before playback

### Changed
- Playback: Removed ffmpegdirect/adaptive routing for all JWPlayer servers — default player handles HLS with audio groups natively
- Playback: All audio track switching via Kodi's native audio button (Uqload, StreamHG, Goodstream, Lulustream) or pre-playback popup (Earnvids)

## [1.5.14] - 2026-07-29

### Added
- Playback: Uqload, StreamHG, and Earnvids servers now use direct embed resolution (bypassing strema.top proxy), reducing start-up delay
- Playback: Audio track selection dialog for Uqload, StreamHG, and Earnvids streams with multiple audio languages (Arabic/English)
- Playback: TLS token activation via urllib (OpenSSL) for Uqload, StreamHG, and Earnvids — CDN was rejecting gnutls connections
- Playback: Uqload server uses `index-a1.m3u8` format (no 'v1' prefix) matching its CDN structure

### Fixed
- Playback: SSL certificate verification now disabled for all urllib requests — Uqload, Earnvids, and other CDN domains had cert chain issues
- Playback: watch_stardima.py updated with matching improvements for all three servers

## [1.5.13] - 2026-07-28

### Added
- Playback: Audio track selection dialog for Goodstream and Lulustream streams with multiple audio languages (Arabic/English)

### Fixed
- Playback: Goodstream streams with muxed audio (no separate Arabic track) now play with audio instead of silent video
- Playback: Lulustream streams with muxed audio now play correctly (was forcing non-existent Arabic audio track)
- Playback: Lulustream `luluvdo.com` domain support added
- Playback: Lulustream eval-encoded pages with multi-audio URL format (comma-separated lang segments) now decode and clean properly

## [1.5.12] - 2026-07-28

### Fixed
- Playback: Goodstream no longer returns 403 Forbidden — addon activates stream token with urllib (OpenSSL) before ffmpegdirect connects (gnutls), and uses browser-like Accept/Accept-Language headers. CDN was rejecting non-OpenSSL TLS connections that hadn't "pre-warmed" the token.

## [1.5.11] - 2026-07-27

### Fixed
- Playback: Goodstream now extracts m3u8 URL directly from the Goodstream embed page instead of going through strema.top's obfuscated player, improving reliability
- Playback: Goodstream uses `master.m3u8` (multi-resolution playlist) with correct `goodstream.one` Referer header for CDN access

## [1.5.10] - 2026-07-27

### Fixed
- Playback: StreamHG streams now use `inputstream.ffmpegdirect` instead of `inputstream.adaptive` (CDN rejected segment requests with Referer header)
- Playback: Goodstream and Lulustream now use `index-v1-a1.m3u8` (direct media playlist) instead of `master.m3u8` (multi-level index), reducing start-up delay
- Playback: Added `premilkyway.com` and `hgplaycdn.com` to Cloudflare bypass domains

## [1.5.9] - 2026-07-27

### Added
- Playback: Lulustream server support via katana obfuscation + base-36 eval decoder
- Playback: Goodstream server support via plain-text JWPlayer config extraction
- Playback: Both servers added to priority list (Lulustream #3, Goodstream #6)
- Playback: URL verification before returning stream (GET request validates m3u8)

### Changed
- Server priority order: Mixdrop > Uqload > Lulustream > StreamHG > Earnvids > Goodstream
- README: Updated server status table and known issues (Lulustream and Goodstream now work)

## [1.5.8] - 2026-07-25

### Added
- Navigation: Page catalog selector between category and titles (Page 1 (1-100), Page 2 (101-200), ...)
- Navigation: Movies/Series sub-menus now show "All" (الكل) instead of repeating the parent label

### Changed
- Back button on title pages now returns to page selector instead of home

## [1.5.7] - 2026-07-25

### Fixed
- UI: Poster images with relative paths from StarDima's JSON API (e.g. `posters/...`) now resolve to full URLs instead of broken `https://posters/...`

## [1.5.6] - 2026-07-25

### Fixed
- Playback: Earnvids, Uqload, and Lulustream HLS streams now use `inputstream.ffmpegdirect` instead of `inputstream.adaptive` (which could not handle their HLS media playlists, causing 30-second timeout and demuxer errors)
- Playback: Earnvids streams now use `index-v1-a1.m3u8` (direct media playlist) instead of `master.m3u8` (multi-level index), reducing start-up delay

## [1.5.5] - 2026-07-24

### Added
- Kids TV: Dedicated playback method setting (defaults to Prefer 576p/SD) independent from global playback setting

## [1.5.4] - 2026-07-24

### Added
- Resolution presets: Prefer 1080p/720p/576p/468p/360p/288p (no popup, silent selection)
- High-res logo overrides for scraped Kids TV channels (MBC 3, Rotana Kids, Karameesh, Majid Kids, Spacetoon, Cartoon Arabia, TRT Cocuk, Moonbug, Afarin TV, Toon Goggles)

### Changed
- Direct channels now appear first in Kids TV list (higher priority)
- Case-insensitive channel dedup (prevents duplicate MBC 3 entries)
- Fixed clearkey DRM scheme for shahid_shaka channels
- Improved Spacetoon logo URL (broken Wikimedia link replaced)

### Removed
- 11 dead/unreliable channels: 4Kids TV, 90's Kids, Disney Channel, Disney Junior, Disney XD, Lego Channel, KidsFlix, Kids Movie Club, LEGO Kids TV, Nick Jr., Forever Kids
- Majid Kids (DRM-protected, not playable on Kodi)

## [1.5.3] - 2026-07-24

### Added
- Kids TV: Added "MBC 3 DZ" channel (edgenextcdn.net stream)
- Kids TV: Added "Majid Kids DZ" channel (starzplayarabia.com HLS stream)

### Changed
- Playback: Simplified resolution selection to "Select Quality Via Dialog" and "Auto Adaptive" (inputstream.adaptive handles quality natively)

### Fixed
- Playback: Fixed crash when playing TV channels caused by filtered HLS playlist approach (data URIs and local file:// playlists with https:// variants are not supported by inputstream.adaptive)
- Playback: Audio now loads correctly with all HLS streams by using master playlist instead of video-only variant URLs

## [1.5.2] - 2026-07-24

### Fixed
- elahmad.ru: Updated stream decryption for new encryption keys and dynamic `da_ta` structure
- elahmad.ru: Added Cryptodome fallback for AES decryption (Android has no `openssl`)
- elahmad.ru: Removed `Cryptodome.Util.Padding` import (not available in pycryptodome 3.4.3 shipped with Kodi)
- elahmad.ru: Removed Referer header for HLS streams (edgenextcdn.net CDN returns 403 with Referer)
- elahmad.ru: Added HLS master playlist variant resolution (Kodi cannot handle separate audio/video renditions)
- elahmad.ru: Reduced HTTP request artificial delay from 1.5s to 0.5s for faster channel start times
