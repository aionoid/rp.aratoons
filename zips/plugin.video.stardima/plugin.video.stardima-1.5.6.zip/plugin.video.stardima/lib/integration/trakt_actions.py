# -*- coding: utf-8 -*-

"""Trakt.tv library actions."""


def trakt_add_series(title):
    pass


def trakt_add_episode(title, season, episode):
    pass


def trakt_mark_watched(title, season, episode):
    pass
