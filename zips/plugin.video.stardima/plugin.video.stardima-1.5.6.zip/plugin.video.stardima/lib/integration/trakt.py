# -*- coding: utf-8 -*-

"""Trakt.tv integration for metadata."""


def trakt_get_series_info(title):
    """Fetch series info from Trakt."""
    pass


def trakt_get_episode_info(title, season, episode):
    """Fetch episode info from Trakt."""
    pass


def trakt_add_to_library(title, season=-1, episode=-1):
    """Add to Trakt library."""
    pass
