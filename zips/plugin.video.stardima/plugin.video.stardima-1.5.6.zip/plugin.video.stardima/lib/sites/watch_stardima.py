# -*- coding: utf-8 -*-
"""
Watch.StarDima scraper — https://watch.stardima.com/watch

WordPress (Dooplay theme) catalog with rich metadata:
- Better poster images
- Full descriptions
- Year, genres, cast info
- Pagination via WP REST API

Playback still uses the existing hyperwatching flow from www.stardima.com.
"""

import re
import json
import html as html_mod
import xbmc
import xbmcgui

from lib.constants import (
    WATCH_BASEURL, WATCH_API, WNT2_USER_AGENT, PLUGIN_TITLE, ADDON_ICON_DICT,
    BASEURL,
)
from lib.common import (
    ensure_full_url, base_url_remove, unescapeHTMLText, item_set_info,
    makeListItem, makeListItemClean,
)
from lib.network import request_helper


# ---------------------------------------------------------------------------
# WP REST API helpers
# ---------------------------------------------------------------------------
_WATCH_HEADERS = {
    'User-Agent': WNT2_USER_AGENT,
    'Accept': 'application/json',
    'Referer': WATCH_BASEURL + '/',
}


def _api_get(url, headers=None):
    """GET a JSON endpoint on watch.stardima.com."""
    hdrs = dict(_WATCH_HEADERS)
    if headers:
        hdrs.update(headers)
    r = request_helper(url, extra_headers=hdrs)
    return r.json()


# ---------------------------------------------------------------------------
# Catalog endpoints — movies, tvshows, episodes
# ---------------------------------------------------------------------------

def get_movies(page=1, per_page=20):
    """Get movies from watch.stardima.com WP REST API.

    Returns: {'items': [(url, title, poster, plot, year), ...], 'last_page': N}
    """
    url = '{}/movies?per_page={}&page={}&_embed=true'.format(WATCH_API, per_page, page)
    r = request_helper(url, extra_headers=_WATCH_HEADERS)
    total_pages = int(r.headers.get('X-WP-TotalPages', 1))
    data = r.json()

    items = []
    for item in data:
        title = unescapeHTMLText(item.get('title', {}).get('rendered', ''))
        poster = _get_poster_from_embedded(item)
        plot = _clean_content(item.get('content', {}).get('rendered', ''))
        year = _get_year(item.get('dtyear', []))
        slug = item.get('slug', '')
        watch_url = '{}/movies/{}/'.format(WATCH_BASEURL, slug)
        items.append((watch_url, title, poster, plot, year))

    return {'items': items, 'last_page': total_pages, 'current_page': page}


def get_tvshows(page=1, per_page=20):
    """Get TV shows from watch.stardima.com WP REST API.

    Returns: {'items': [(url, title, poster, plot, year), ...], 'last_page': N}
    """
    url = '{}/tvshows?per_page={}&page={}&_embed=true'.format(WATCH_API, per_page, page)
    r = request_helper(url, extra_headers=_WATCH_HEADERS)
    total_pages = int(r.headers.get('X-WP-TotalPages', 1))
    data = r.json()

    items = []
    for item in data:
        title = unescapeHTMLText(item.get('title', {}).get('rendered', ''))
        poster = _get_poster_from_embedded(item)
        plot = _clean_content(item.get('content', {}).get('rendered', ''))
        year = _get_year(item.get('dtyear', []))
        slug = item.get('slug', '')
        watch_url = '{}/tvshows/{}/'.format(WATCH_BASEURL, slug)
        items.append((watch_url, title, poster, plot, year))

    return {'items': items, 'last_page': total_pages, 'current_page': page}


def get_episodes(page=1, per_page=20):
    """Get episodes from watch.stardima.com WP REST API.

    Returns: {'items': [(url, title, poster, plot), ...], 'last_page': N}
    """
    url = '{}/episodes?per_page={}&page={}&_embed=true'.format(WATCH_API, per_page, page)
    r = request_helper(url, extra_headers=_WATCH_HEADERS)
    total_pages = int(r.headers.get('X-WP-TotalPages', 1))
    data = r.json()

    items = []
    for item in data:
        title = unescapeHTMLText(item.get('title', {}).get('rendered', ''))
        poster = _get_poster_from_embedded(item)
        plot = _clean_content(item.get('content', {}).get('rendered', ''))
        slug = item.get('slug', '')
        watch_url = '{}/episodes/{}/'.format(WATCH_BASEURL, slug)
        items.append((watch_url, title, poster, plot))

    return {'items': items, 'last_page': total_pages, 'current_page': page}


# ---------------------------------------------------------------------------
# Search via WP REST API
# ---------------------------------------------------------------------------

def _get_poster_from_embedded(item):
    """Extract poster URL from _embedded/wp:featuredmedia or dt_poster_a size."""
    embedded = item.get('_embedded', {})
    fm_list = embedded.get('wp:featuredmedia', [])
    if fm_list:
        fm = fm_list[0]
        # Prefer dt_poster_a (185x278) or medium (200x300) for Kodi poster display
        sizes = fm.get('media_details', {}).get('sizes', {})
        if 'dt_poster_a' in sizes:
            return sizes['dt_poster_a'].get('source_url', '')
        if 'medium' in sizes:
            return sizes['medium'].get('source_url', '')
        return fm.get('source_url', '')
    return ''


def search_episodes_for_show(show_title, per_page=None):
    """Search episodes on watch.stardima.com that belong to a specific TV show.

    Uses the WP REST API episodes endpoint with the show title as search query.
    Filters results to only include episodes whose title starts with the show title.

    Returns: [(ep_url, ep_title, ep_poster), ...]
    """
    import urllib.parse as up

    log = lambda msg: xbmc.log('AraToons (watch): {}'.format(msg), xbmc.LOGDEBUG)

    # WP REST API caps per_page at 100
    if per_page is None or per_page > 100:
        per_page = 100

    # Clean the show title - remove common suffixes for better matching
    clean_title = re.sub(r'\s*(?:مدبلج|مترجم|عربي)\s*$', '', show_title, flags=re.IGNORECASE).strip()
    # Extract English parts for searching
    english_parts = [p.strip() for p in re.findall(r'([A-Za-z0-9\s]{3,})', clean_title)]
    # Build search terms: English parts first (more reliable), then full title
    search_terms = english_parts if english_parts else [clean_title]

    results = []
    for term in search_terms:
        term = term.strip()
        if not term or len(term) < 3:
            continue
        # URL-encode the search term (handles Arabic + spaces)
        encoded_term = up.quote(term)
        url = '{}/episodes?search={}&per_page={}'.format(WATCH_API, encoded_term, per_page)
        log('searching episodes for: {} (url: {})'.format(term, url))
        try:
            r = request_helper(url, extra_headers=_WATCH_HEADERS)
            data = r.json()
            log('found {} episodes for: {}'.format(len(data), term))
            for item in data:
                ep_title = unescapeHTMLText(item.get('title', {}).get('rendered', ''))
                # Check if episode title contains the search term
                ep_clean = re.sub(r'\s*(?:مدبلج|مترجم|عربي)\s*$', '', ep_title, flags=re.IGNORECASE).strip()
                if term.lower() in ep_clean.lower():
                    poster = _get_poster_from_embedded(item)
                    slug = item.get('slug', '')
                    ep_url = '{}/episodes/{}/'.format(WATCH_BASEURL, slug)
                    # Avoid duplicates
                    if ep_url not in [r[0] for r in results]:
                        results.append((ep_url, ep_title, poster))
        except Exception as e:
            log('search failed for {}: {}'.format(term, e))
            pass
        if results:
            break

    # Sort episodes by title
    results.sort(key=lambda x: x[1])
    log('total episodes for show: {}'.format(len(results)))
    return results


def search(query, page=1, per_page=20, post_type=None):
    """Search watch.stardima.com via WP REST API.

    post_type: None (all), 'movies', 'tvshows', or 'episodes'
    Returns: {'results': [{url, title, poster, plot, year, type}], 'last_page': N}
    """
    results = []
    types_to_search = [post_type] if post_type else ['movies', 'tvshows', 'episodes']

    max_pages = 1
    for pt in types_to_search:
        url = '{}/{}?search={}&per_page={}&page={}&_embed=true'.format(WATCH_API, pt, query, per_page, page)
        try:
            r = request_helper(url, extra_headers=_WATCH_HEADERS)
            tp = int(r.headers.get('X-WP-TotalPages', 1))
            max_pages = max(max_pages, tp)
            data = r.json()
            for item in data:
                title = unescapeHTMLText(item.get('title', {}).get('rendered', ''))
                poster = _get_poster_from_embedded(item)
                plot = _clean_content(item.get('content', {}).get('rendered', ''))
                year = _get_year(item.get('dtyear', []))
                slug = item.get('slug', '')
                watch_url = '{}/{}/{}'.format(WATCH_BASEURL, pt, slug)
                results.append({
                    'url': watch_url,
                    'title': title,
                    'poster': poster,
                    'plot': plot,
                    'year': year,
                    'type': pt,
                })
        except Exception:
            pass

    return {'results': results, 'last_page': max_pages, 'current_page': page}


# ---------------------------------------------------------------------------
# Episode resolution — extract hyperwatching URL from watch.stardima.com
# ---------------------------------------------------------------------------

def resolve_watch_episode(watch_url):
    """Resolve a watch.stardima.com episode/movie URL to a hyperwatching embed URL.

    Returns: hyperwatching_url or None
    """
    try:
        r = request_helper(watch_url, extra_headers={'Referer': WATCH_BASEURL + '/'})
        html_text = r.text

        # Find hyperwatching embed URL (v2 format: /watch/{hashid})
        hw_match = re.search(r'https://v2\.hyperwatching\.com/watch/([a-zA-Z0-9]+)', html_text)
        if hw_match:
            return 'https://v2.hyperwatching.com/watch/{}'.format(hw_match.group(1))

        # Find hyperwatching iframe format (movies use: /iframe/{hashid})
        hw_iframe = re.search(r'https://hyperwatching\.com/iframe/([a-zA-Z0-9]+)', html_text)
        if hw_iframe:
            return 'https://hyperwatching.com/iframe/{}'.format(hw_iframe.group(1))

        # Try og:video
        og_m = re.search(r'<meta property="og:video"[^>]+content="([^"]+)"', html_text)
        if og_m:
            return og_m.group(1)

        # Try iframe src
        iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', html_text)
        if iframe_m:
            return iframe_m.group(1)

    except Exception:
        pass

    return None


# ---------------------------------------------------------------------------
# Get episode servers from watch.stardima.com (same hyperwatching flow)
# ---------------------------------------------------------------------------

def get_watch_episode_servers(watch_url):
    """Get available servers for a watch.stardima.com episode.

    Returns: [{name, label, id}, ...] or []
    """
    embed_url = resolve_watch_episode(watch_url)
    if not embed_url:
        return []

    try:
        r = request_helper(embed_url, extra_headers={'Referer': watch_url})
        hw_html = r.text

        data_page_m = re.search(r'data-page="([^"]+)"', hw_html)
        if not data_page_m:
            return []

        data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
        video = data_page.get('props', {}).get('video', {})
        servers = video.get('servers', [])

        result = []
        priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Streamhg': 2, 'Earnvids': 3, 'Goodstream': 4}
        for s in servers:
            if s.get('id', 0) == 0:
                continue
            name = s.get('name', '')
            status = s.get('status', '')
            label = name + (' (ready)' if status == 'completed' else ' (processing)')
            result.append({
                'name': name,
                'label': label,
                'id': s.get('id', 0),
                'priority': priority_order.get(name, 99),
            })

        result.sort(key=lambda s: s['priority'])
        return result
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Resolve watch episode to playable stream (same hyperwatching flow)
# ---------------------------------------------------------------------------

def resolve_watch_stream(watch_url, server_name=None):
    """Resolve a watch.stardima.com episode URL to a playable stream.

    Uses the same hyperwatching server flow as the main stardima scraper.
    """
    log = lambda msg: xbmc.log('AraToons (watch): {}'.format(msg), xbmc.LOGINFO)
    log('resolving watch episode: {}'.format(watch_url))

    embed_url = resolve_watch_episode(watch_url)
    if not embed_url:
        log('no embed_url found')
        return None

    # Fetch hyperwatching page
    r = request_helper(embed_url, extra_headers={'Referer': watch_url})
    hw_html = r.text

    data_page_m = re.search(r'data-page="([^"]+)"', hw_html)
    if not data_page_m:
        return None

    data_page = json.loads(html_mod.unescape(data_page_m.group(1)))
    video = data_page.get('props', {}).get('video', {})
    hashid = video.get('hashid', '')
    servers = video.get('servers', [])

    if not hashid or not servers:
        log('no hashid/servers')
        return None

    # Filter to specific server if requested
    if server_name:
        matched = [s for s in servers if s.get('name', '') == server_name and s.get('id', 0) != 0]
        if matched:
            servers = matched
        else:
            log('server {} not found'.format(server_name))
            return None

    # Reuse the server extraction functions from stardima.py
    from lib.sites.stardima import (
        _extract_mixdrop_url, _extract_streamhg_url, _extract_filemoon_url,
        _extract_earnvids_url, _extract_goodstream_url, _extract_jwplayer_url,
        _clean_jwplayer_url, _extract_jwplayer_cookies, _verify_stream_url,
    )

    def _referer(base_url):
        import urllib.parse as up
        p = up.urlparse(base_url)
        return p.scheme + '://' + p.netloc + '/'

    hw_base = 'https://v2.hyperwatching.com'

    # Server priority: Mixdrop > Uqload > StreamHG > Earnvids > Goodstream
    priority_order = {'Mixdrop': 0, 'Uqload': 1, 'Streamhg': 2, 'Earnvids': 3, 'Goodstream': 4}
    priority_servers = [s for s in servers if s.get('name', '') in priority_order and s.get('id', 0) != 0]
    other_servers = [s for s in servers if s.get('name', '') not in priority_order and s.get('id', 0) != 0]
    priority_servers.sort(key=lambda s: priority_order.get(s.get('name', ''), 99))
    server_order = priority_servers + other_servers

    for server in server_order:
        server_id = server.get('id', 0)
        name = server.get('name', '')
        log('trying server: {} (id={})'.format(name, server_id))

        api_url = '{}/embed/{}/server/{}/url'.format(hw_base, hashid, server_id)
        r3 = request_helper(api_url, extra_headers={'Referer': embed_url})
        try:
            api_data = r3.json()
        except Exception:
            continue

        watch_server_url = api_data.get('watch_url', '')
        if not watch_server_url:
            continue

        # Fetch the embed page
        r4 = request_helper(watch_server_url, extra_headers={'Referer': embed_url})
        player_html = r4.text

        # --- Mixdrop ---
        if name == 'Mixdrop':
            mp4_url = _extract_mixdrop_url(player_html)
            if mp4_url:
                return (mp4_url, _referer(watch_server_url))

        # --- StreamHG ---
        if 'hgplaycdn.com' in watch_server_url:
            m3u8_url = _extract_streamhg_url(player_html)
            if m3u8_url:
                verified = _verify_stream_url(m3u8_url, _referer(watch_server_url))
                if verified:
                    return (m3u8_url, _referer(watch_server_url))
                continue

        # --- Filemoon ---
        if 'filemoon' in watch_server_url or 'filemoon' in player_html:
            fm_url = _extract_filemoon_url(watch_server_url, player_html, embed_url)
            if fm_url:
                return (fm_url, _referer(watch_server_url))

        # --- Earnvids ---
        if 'minochinos.com' in watch_server_url or 'earnvids' in watch_server_url or 'earnvids' in player_html:
            ev_url = _extract_earnvids_url(player_html)
            if ev_url:
                return (ev_url, _referer(watch_server_url))

        # --- Goodstream ---
        if 'goodstream' in watch_server_url:
            gs_url = _extract_goodstream_url(player_html)
            if gs_url:
                return (gs_url, _referer(watch_server_url))

        # --- Generic: try m3u8/MP4 extraction ---
        m3u8_m = re.search(r'src="([^"]*\.m3u8[^"]*)"', player_html)
        if m3u8_m:
            return (m3u8_m.group(1), _referer(watch_server_url))

        src_m = re.search(r'<source[^>]+src="([^"]+)"', player_html)
        if src_m:
            return (src_m.group(1), _referer(watch_server_url))

        # --- Strema.top proxy ---
        if 'strema.top' in watch_server_url:
            import urllib.parse as up
            parsed = up.urlparse(watch_server_url)
            params = up.parse_qs(parsed.query)
            if 'id' in params:
                actual_url = up.unquote(params['id'][0])
                r5 = request_helper(actual_url, extra_headers={'Referer': watch_server_url})
                actual_html = r5.text

                has_video_content = ('<video' in actual_html or '<source' in actual_html)
                strema_has_error = (not has_video_content and (
                    'not found' in actual_html.lower() or
                    'file has been deleted' in actual_html.lower() or
                    len(actual_html) < 200))

                if not strema_has_error:
                    if 'hgplaycdn.com' in actual_url:
                        m3u8_url = _extract_streamhg_url(actual_html)
                        if m3u8_url:
                            verified = _verify_stream_url(m3u8_url, _referer(actual_url))
                            if verified:
                                return (m3u8_url, _referer(actual_url))
                            continue
                    if 'goodstream' in actual_url:
                        gs_url = _extract_goodstream_url(actual_html)
                        if gs_url:
                            return (gs_url, _referer(actual_url))

                jw_source_html = actual_html if not strema_has_error else player_html
                jw_url = _extract_jwplayer_url(jw_source_html)
                if jw_url:
                    jw_url = _clean_jwplayer_url(jw_url)
                    referer = _referer(actual_url if not strema_has_error else watch_server_url)
                    cookie = _extract_jwplayer_cookies(jw_source_html)
                    verified = _verify_stream_url(jw_url, referer, cookie)
                    if verified:
                        return (jw_url, referer)
                    continue

    log('no playable stream found')
    return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _clean_content(rendered_html):
    """Strip HTML tags from WordPress content and unescape."""
    if not rendered_html:
        return ''
    text = rendered_html.replace('<p class="wp-block-paragraph">', '').replace('</p>', '')
    text = re.sub(r'<[^>]+>', '', text)
    return unescapeHTMLText(text)


def _get_year(dtyear):
    """Extract year from dtyear field."""
    if not dtyear:
        return ''
    return str(dtyear[0])
