# -*- coding: utf-8 -*-
"""
Elahmad Kids TV scraper — https://www.elahmad.ru

Live TV channels for kids (MBC3, Spacetoon, Karameesh, Cartoon Network, etc.)
Streams are HLS (m3u8) resolved via encrypted POST requests.
"""

import re
import json
import base64
import subprocess
import urllib.parse
import xbmc
import xbmcgui

from lib.constants import WNT2_USER_AGENT, PLUGIN_TITLE, ADDON_ICON_DICT
from lib.common import unescapeHTMLText
from lib.network import request_helper

# Pure-Python AES-CBC decryption (fallback when openssl is unavailable, e.g. Android)
try:
    from Cryptodome.Cipher import AES as _AES
    _HAS_CRYPTO = True
except ImportError:
    try:
        from Crypto.Cipher import AES as _AES
        _HAS_CRYPTO = True
    except ImportError:
        _HAS_CRYPTO = False

# Also try Python stdlib ssl for decryption as last resort
_HAS_PYCRYPTO = False

ELAHMAD_BASE = 'https://www.elahmad.ru'
ELAHMAD_KIDS_PAGE = ELAHMAD_BASE + '/tv/mobile-live-stream/?id=kids_tv'

# Direct m3u8 channels (not from elahmad.ru scraping)
# Format: (title, stream_url, poster_url)
# For shahid_shaka channels, use the full elahmad URL as stream_url
DIRECT_CHANNELS = [
    ('Gulli', 'http://99.27.51.147:8080/Gulli/index.m3u8',
     'https://i.imgur.com/kqYssbW.png'),
    ('Amou Yazid TV', 'http://mkstream.servehttp.com:1940/AmouYazid/ay1/playlist.m3u8',
     'https://i.imgur.com/L8UPGPC.png'),
    ('Roya Kids', 'https://playlist.fasttvcdn.com/pl/ptllxjd03j6g9oxxjdfapg/roya-kids/playlist.m3u8',
     'https://i.imgur.com/acuCGF8.png'),
    ('Roya Kids Originals',
     'https://playlist.fasttvcdn.com/pl/ptllxjd03j6g9oxxjdfapg/roya-kids-originals/playlist.m3u8',
     'https://i.imgur.com/acuCGF8.png'),
    ('Sat 7 Kids', 'https://svs.itworkscdn.net/sat7kidslive/sat7kids.smil/playlist_dvr.m3u8',
     'https://i.imgur.com/M0ik0i2.png'),
    ('Spacetoon Arabic',
     'https://live-uae-next.spacetoongo.com/ST_MENA_NEXT/hls/r9p2hjipmw2kl.m3u8',
     'https://static.wikia.nocookie.net/logopedia/images/e/ea/Spacetoon_logo_2020.png/revision/latest/scale-to-width-down/512?cb=20230127005055'),
    # Added from index.m3u
    ('Taha TV', 'https://stream.starmenajo.com/hls/app/live/ts:fhd.m3u8',
     'https://i.imgur.com/hdsrxvX.png'),
    ('MBC 3 USA',
     'https://shd-gcp-live.edgenextcdn.net/live/bitmovin-mbc-3-usa/5d58265a862a476dc7f97694addb5ded/index.m3u8',
     'https://i.imgur.com/PVt8OPN.png'),
    ('MBC 3 DZ',
     'https://shd-gcp-live.edgenextcdn.net/live/bitmovin-mbc-3-usa/5d58265a862a476dc7f97694addb5ded/index.m3u8',
     'https://i.imgur.com/PVt8OPN.png'),
    ('Atfal & Mawaheb TV',
     'https://5aafcc5de91f1.streamlock.net/atfal1.com/atfal2/playlist.m3u8',
     'https://i.imgur.com/Y2BqP9m.png'),
]

# High-res logo overrides for channels scraped from elahmad.ru
# Maps channel title (case-insensitive) to a better logo URL.
# Applied in get_kids_channels() after scraping.
LOGO_OVERRIDES = {
    'mbc 3 eur': 'https://i.imgur.com/PVt8OPN.png',
    'rotana kids': 'https://static.wikia.nocookie.net/logopedia/images/c/c6/KIDS-Main-Logo.png/revision/latest/scale-to-width-down/512?cb=20200817052307',
    'قناة كراميش': 'https://static.wikia.nocookie.net/logopedia/images/f/fa/Karameesh_TV_Logo.jpeg/revision/latest/scale-to-width-down/512?cb=20260119085049',
    'كرتون عربي': 'https://static.wikia.nocookie.net/logopedia/images/e/ee/Cartoon_Network_2010.svg/revision/latest/scale-to-width-down/512?cb=20210726224754',
    'moonbug kids': 'https://i.imgur.com/vZHtxQb.png',
    'afarin tv': 'https://i.imgur.com/6MnXD7g.png',
    'toon goggles': 'https://i.imgur.com/aqane40.png',
}

# Shahid Shaka channels (DASH + DRM) - requires AES decryption (not available on Android).
# Removed: Majid Kids streams use starzplayarabia CDN with DRM that Kodi cannot handle.
SHAHID_SHAKA_CHANNELS_RAW = []

# OpenSSL path for AES decryption (found on NixOS)
_OPENSSL_PATH = None


def _find_openssl():
    """Find the openssl binary path."""
    global _OPENSSL_PATH
    if _OPENSSL_PATH:
        return _OPENSSL_PATH
    import os
    # Common paths
    for path in [
        '/nix/store/2di90l89y2ygdy3rbws7dhg9nrvd3pnx-openssl-3.6.1-bin/bin/openssl',
        '/run/current-system/sw/bin/openssl',
        '/usr/bin/openssl',
    ]:
        if os.path.exists(path):
            _OPENSSL_PATH = path
            return path
    # Try to find it
    try:
        result = subprocess.run(['which', 'openssl'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            _OPENSSL_PATH = result.stdout.strip()
            return _OPENSSL_PATH
    except Exception:
        pass
    return None


def _decrypt_aes(link_4, key_hex, iv_hex):
    """Decrypt AES-256-CBC encrypted stream URL (link_4).

    key_hex and iv_hex are hex strings from the server response.
    Falls back to Cryptodome if openssl is unavailable.
    """
    try:
        encrypted = base64.b64decode(link_4)
    except Exception:
        return None

    # Try openssl first
    openssl = _find_openssl()
    if openssl:
        try:
            with open('/tmp/elahmad_enc.bin', 'wb') as f:
                f.write(encrypted)

            result = subprocess.run([
                openssl, 'enc', '-aes-256-cbc', '-d',
                '-in', '/tmp/elahmad_enc.bin',
                '-K', key_hex, '-iv', iv_hex, '-nopad'
            ], capture_output=True, timeout=10)

            if result.returncode == 0:
                decrypted = result.stdout
                pad_len = decrypted[-1]
                if 0 < pad_len <= 32:
                    decrypted = decrypted[:-pad_len]
                    return decrypted.decode('utf-8', errors='replace')
        except Exception:
            pass

    # Fallback: pure Python AES decryption (for Android / no openssl)
    return _decrypt_aes_pure(encrypted, key_hex, iv_hex)


def _decrypt_aes_pure(encrypted, key_hex, iv_hex):
    """Pure Python AES-256-CBC decryption using Cryptodome.

    encrypted: raw bytes
    key_hex: hex string of key (e.g. '33633561...')
    iv_hex: hex string of IV (e.g. '61663734...')

    Returns decrypted string or None on failure.
    """
    if not _HAS_CRYPTO:
        return None
    try:
        key_bytes = bytes.fromhex(key_hex)
        iv_bytes = bytes.fromhex(iv_hex)
        cipher = _AES.new(key_bytes, _AES.MODE_CBC, iv_bytes)
        decrypted = cipher.decrypt(encrypted)
        # PKCS7 unpadding
        pad_len = decrypted[-1]
        if 0 < pad_len <= 32:
            decrypted = decrypted[:-pad_len]
            return decrypted.decode('utf-8', errors='replace')
    except Exception:
        pass
    return None


def _decrypt_link1(ciphertext_b64, key_str=None, iv_str=None):
    """Decrypt link_1 from arabic-tv-online.php player.

    Uses AES-256-CBC with key/IV extracted from page JS (CryptoJS-compatible).
    Key and IV are UTF-8 strings passed to CryptoJS.enc.Utf8.parse().
    Default keys: '3c5a27040d470ad509f45c3b9d34f4e2' / 'af74c88b5942fe2a'
    """
    if key_str is None:
        key_str = '3c5a27040d470ad509f45c3b9d34f4e2'
    if iv_str is None:
        iv_str = 'af74c88b5942fe2a'

    # Key and IV are the literal strings, converted to hex via UTF-8 encoding
    key_hex = key_str.encode('utf-8').hex()
    iv_hex = iv_str.encode('utf-8').hex()

    try:
        encrypted = base64.b64decode(ciphertext_b64)
    except Exception:
        return None

    # Try openssl first
    openssl = _find_openssl()
    if openssl:
        try:
            with open('/tmp/elahmad_link1.bin', 'wb') as f:
                f.write(encrypted)

            result = subprocess.run([
                openssl, 'enc', '-aes-256-cbc', '-d',
                '-in', '/tmp/elahmad_link1.bin',
                '-K', key_hex, '-iv', iv_hex, '-nopad'
            ], capture_output=True, timeout=10)

            if result.returncode == 0:
                decrypted = result.stdout
                pad_len = decrypted[-1]
                if 0 < pad_len <= 32:
                    decrypted = decrypted[:-pad_len]
                    return decrypted.decode('utf-8', errors='replace')
        except Exception:
            pass

    # Fallback: pure Python AES decryption (for Android / no openssl)
    return _decrypt_aes_pure(encrypted, key_hex, iv_hex)


def _get_embed_endpoint(page_html):
    """Extract the embed_result endpoint from page HTML."""
    m = re.search(r"embed_result[^=]*=\s*'([^']+)'", page_html)
    if m:
        return m.group(1)
    # Fallback: try to find in the loadChannel function
    m = re.search(r"xhr\.open\('POST',\s*'([^']+)'", page_html)
    if m:
        return m.group(1)
    return None


def _get_csrf(page_html):
    """Extract CSRF token from page HTML."""
    m = re.search(r'<meta name="csrf-token" content="([^"]+)"', page_html)
    return m.group(1) if m else ''


def get_kids_channels():
    """Scrape the kids TV page and return list of channels.

    Returns: [(channel_url, title, poster), ...]
    """
    log = lambda msg: xbmc.log('AraToons (elahmad): {}'.format(msg), xbmc.LOGDEBUG)

    try:
        r = request_helper(ELAHMAD_KIDS_PAGE)
        html = r.text

        # Decode windows-1256 if needed
        if not isinstance(html, str):
            html = html.decode('windows-1256', errors='replace')

        # Extract channel cards
        cards = re.findall(
            r'<a href="([^"]+)"[^>]*>.*?'
            r'<div[^>]*class="[^"]*card[^"]*"[^>]*>.*?'
            r'<div[^>]*class="[^"]*card-body[^"]*"[^>]*>.*?'
            r'<img[^>]+src="([^"]+)"[^>]*>.*?'
            r'</div>.*?'
            r'<div[^>]*class="[^"]*card-header[^"]*"[^>]*>.*?'
            r'([^<]+)',
            html, re.DOTALL
        )

        channels = []
        seen = set()
        for url, img, title in cards:
            title = unescapeHTMLText(title.strip())
            # Skip hidden channels (display:none)
            # Build full URL and image URL
            if not url.startswith('http'):
                full_url = ELAHMAD_BASE + url
            else:
                full_url = url
            if not img.startswith('http'):
                full_img = ELAHMAD_BASE + img
            else:
                full_img = img

            # Skip duplicates by title (case-insensitive)
            if title.lower() in seen:
                continue
            seen.add(title.lower())

            # Skip youtube links for now (need different handling)
            if 'youtube.php' in url:
                continue

            # Skip broken/unreliable scraped channels
            blocked_titles = {'mbc 3', 'سبيس تون', 'طيور بيبي', 'majid kids', 'trt cocuk'}
            if title.lower() in blocked_titles:
                continue

            # Apply high-res logo override if available
            poster = LOGO_OVERRIDES.get(str(title).lower(), full_img)
            channels.append((full_url, title, poster))

        log('found {} kids channels'.format(len(channels)))

        # Prepend direct m3u8 channels (higher priority, case-insensitive dedup)
        direct = []
        for title, stream_url, poster in DIRECT_CHANNELS:
            if title.lower() not in seen:
                seen.add(title.lower())
                # Use direct:// prefix so resolve_channel_stream knows it's a raw m3u8
                direct.insert(0, ('direct://' + stream_url, title, poster))
        channels = direct + channels
        log('added {} direct channels'.format(len(direct)))

        # Append shahid_shaka channels (DASH + DRM)
        # Only if we have crypto support (openssl or pycryptodome)
        if _HAS_CRYPTO or _find_openssl():
            shaka = []
            for title, channel_url, poster in SHAHID_SHAKA_CHANNELS_RAW:
                if title not in seen:
                    seen.add(title)
                    shaka.append((channel_url, title, poster))
            channels.extend(shaka)
            log('added {} shahid_shaka channels'.format(len(shaka)))
        else:
            log('shahid_shaka channels skipped: no crypto available')

        return channels

    except Exception as e:
        log('failed to fetch kids channels: {}'.format(e))
        return []


def _resolve_shahid_shaka(channel_url, log):
    """Resolve shahid_shaka.php channels (DASH + Widevine clearkey).

    POSTs channel ID to get link_4/ck, decrypts to MPD URL + clearkey.
    Returns: (mpd_url, clearkey_dict) or None
    """
    try:
        # Extract channel ID from URL
        id_m = re.search(r'[?&]id=([^&]+)', channel_url)
        ch_id = id_m.group(1) if id_m else ''
        if not ch_id:
            log('no channel ID in shahid_shaka URL')
            return None

        log('resolving shahid_shaka: id={}'.format(ch_id))

        # POST to get encrypted data
        parsed = urllib.parse.urlparse(channel_url)
        post_url = ELAHMAD_BASE + parsed.path
        post_data = urllib.parse.urlencode({'id': ch_id}).encode()
        post_headers = {
            'User-Agent': WNT2_USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': channel_url,
        }

        r = request_helper(post_url, data=post_data, extra_headers=post_headers)
        resp_text = r.text
        if not isinstance(resp_text, str):
            resp_text = resp_text.decode('utf-8', errors='replace')

        data = json.loads(resp_text)
        if 'error' in data or 'link_4' not in data:
            log('shahid_shaka response error: {}'.format(data))
            return None

        # Decrypt link_4 -> MPD URL
        mpd_url = _decrypt_aes(data['link_4'], data.get('key', ''), data.get('iv', ''))
        if not mpd_url:
            log('failed to decrypt shahid_shaka link_4')
            return None

        # Decrypt ck -> clearkey KID:key mapping
        clearkey = {}
        if data.get('text') == 'true' and data.get('ck'):
            try:
                ck_raw = _decrypt_aes(data['ck'], data.get('key', ''), data.get('iv', ''))
                if ck_raw:
                    clearkey = json.loads(ck_raw)
            except Exception:
                pass

        log('shahid_shaka resolved: mpd={}, clearkey={}'.format(mpd_url[:80], bool(clearkey)))
        return (mpd_url, clearkey)

    except Exception as e:
        log('shahid_shaka resolve failed: {}'.format(e))
        return None


def resolve_channel_stream(channel_url):
    """Resolve a channel page to an HLS/DASH stream URL.

    Returns:
    - str for direct m3u8 streams
    - str for resolved HLS streams
    - dict with 'mpd_url' and 'clearkey' for DASH+DRM streams
    - None on failure
    """
    log = lambda msg: xbmc.log('AraToons (elahmad): {}'.format(msg), xbmc.LOGDEBUG)
    log('resolving channel: {}'.format(channel_url))

    # --- direct m3u8 stream ---
    if channel_url.startswith('direct://'):
        url = channel_url[len('direct://'):]
        # Fetch the manifest to warm up DNS/TLS connection. inputstream.adaptive
        # can time out on cold connections to edgenextcdn.net.
        try:
            r = request_helper(url)
            if r.status_code == 200:
                log('direct stream manifest fetched successfully')
        except Exception:
            log('direct stream manifest fetch failed, proceeding anyway')
        return url

    # --- shahid_shaka.php player (DASH + clearkey DRM) ---
    if 'shahid_shaka.php' in channel_url:
        result = _resolve_shahid_shaka(channel_url, log)
        if result:
            mpd_url, clearkey = result
            return {'mpd_url': mpd_url, 'clearkey': clearkey}
        return None

    # --- arabic-tv-online.php player (link_1) ---
    if 'arabic-tv-online.php' in channel_url:
        return _resolve_arabic_tv_online(channel_url, log)

    # --- embed_result player (link_4) ---
    try:
        r = request_helper(channel_url, extra_headers={'Referer': ELAHMAD_KIDS_PAGE})
        html = r.text
        if not isinstance(html, str):
            html = html.decode('windows-1256', errors='replace')

        # Extract CSRF token
        csrf = _get_csrf(html)
        if not csrf:
            log('no CSRF token found')
            return None

        # Extract embed endpoint
        embed_endpoint = _get_embed_endpoint(html)
        if not embed_endpoint:
            log('no embed endpoint found')
            return None

        # Extract channel ID from URL
        id_m = re.search(r'[?&]id=([^&]+)', channel_url)
        ch_id = id_m.group(1) if id_m else ''
        if not ch_id:
            log('no channel ID found')
            return None

        log('channel ID: {}, endpoint: {}'.format(ch_id, embed_endpoint))

        # POST to embed endpoint
        post_data = urllib.parse.urlencode({'id': ch_id, 'csrf_token': csrf}).encode()
        embed_url = ELAHMAD_BASE + embed_endpoint

        post_headers = {
            'User-Agent': WNT2_USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': channel_url,
        }

        r2 = request_helper(embed_url, data=post_data, extra_headers=post_headers)
        resp_text = r2.text
        if not isinstance(resp_text, str):
            resp_text = resp_text.decode('utf-8', errors='replace')

        data = json.loads(resp_text)

        if 'error' in data:
            log('server error: {}'.format(data['error']))
            return None

        if 'link_4' in data:
            stream_url = _decrypt_aes(data['link_4'], data.get('key', ''), data.get('iv', ''))
            if stream_url:
                log('resolved stream: {}'.format(stream_url[:80]))
                return stream_url

        log('no stream URL in response')
        return None

    except Exception as e:
        log('resolve failed: {}'.format(e))
        return None




def _resolve_arabic_tv_online(channel_url, log):
    """Resolve arabic-tv-online.php channels (link_1 player).

    These pages embed da_ta in the HTML, POST it to themselves,
    and return link_1 which is AES-256-CBC encrypted.
    The encryption key/IV are extracted from the page's my_crypt() call.
    """
    try:
        r = request_helper(channel_url, extra_headers={'Referer': ELAHMAD_KIDS_PAGE})
        html = r.text
        if not isinstance(html, str):
            html = html.decode('windows-1256', errors='replace')

        # Extract da_ta from the page (may have trailing commas)
        da_ta_match = re.search(r'var\s+da_ta\s*=\s*({[^;]+});', html)
        if not da_ta_match:
            log('no da_ta found in arabic-tv-online page')
            return None

        da_ta_raw = da_ta_match.group(1)
        # Remove trailing commas before } or ,}
        da_ta_raw = re.sub(r',\s*}', '}', da_ta_raw)
        da_ta = json.loads(da_ta_raw)
        log('da_ta: {}'.format(da_ta))

        # Extract encryption key and IV from my_crypt() call in page JS
        # e.g.: my_crypt(a.link_1,"3c5a27040d470ad509f45c3b9d34f4e2","af74c88b5942fe2a")
        crypt_match = re.search(
            r'my_crypt\s*\([^,]+,\s*([^,]+),\s*([^)]+)\)',
            html
        )
        if crypt_match:
            enc_key = crypt_match.group(1).strip().strip('"').strip("'")
            enc_iv = crypt_match.group(2).strip().strip('"').strip("'").rstrip(')')
            log('extracted encryption key: {} iv: {}'.format(enc_key[:16], enc_iv[:16]))
        else:
            # Fallback to default keys
            enc_key = '3c5a27040d470ad509f45c3b9d34f4e2'
            enc_iv = 'af74c88b5942fe2a'
            log('using default encryption keys')

        # POST da_ta to the same URL (window.location.pathname)
        post_data = urllib.parse.urlencode(da_ta).encode()
        post_headers = {
            'User-Agent': WNT2_USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Referer': channel_url,
        }

        # Extract the pathname for the POST target
        parsed = urllib.parse.urlparse(channel_url)
        post_url = ELAHMAD_BASE + parsed.path

        r2 = request_helper(post_url, data=post_data, extra_headers=post_headers)
        resp_text = r2.text
        if not isinstance(resp_text, str):
            resp_text = resp_text.decode('utf-8', errors='replace')

        data = json.loads(resp_text)

        if 'link_1' not in data:
            log('no link_1 in arabic-tv-online response')
            return None

        stream_url = _decrypt_link1(data['link_1'], key_str=enc_key, iv_str=enc_iv)
        if stream_url:
            log('resolved arabic-tv-online stream: {}'.format(stream_url[:80]))
            return stream_url

        log('failed to decrypt link_1')
        return None

    except Exception as e:
        log('arabic-tv-online resolve failed: {}'.format(e))
        return None
