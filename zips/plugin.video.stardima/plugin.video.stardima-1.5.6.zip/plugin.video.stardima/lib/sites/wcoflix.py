# Placeholder: inherits from stardima module
from lib.sites.stardima import *
