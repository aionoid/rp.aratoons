# -*- coding: utf-8 -*-

import os
import json

from lib.common import ensure_path_exists, translate_path
from lib.constants import RESOURCE_URL, PLUGIN_ID


def recently_watched_load():
    data = {}
    fp = translate_path(RESOURCE_URL + 'data/recently_watched.json')
    if os.path.exists(fp):
        with open(fp, 'r', encoding='utf8') as f:
            data = json.load(f)
    return data


def recently_watched_add(name, url):
    data = recently_watched_load()
    fp = translate_path(RESOURCE_URL + 'data/recently_watched.json')
    
    if name not in data:
        ensure_path_exists(translate_path(RESOURCE_URL + 'data'))
        data[name] = {'name': name, 'url': url}
        with open(fp, 'w', encoding='utf8') as f:
            json.dump(data, f)


def recently_watched_remove(name):
    data = recently_watched_load()
    fp = translate_path(RESOURCE_URL + 'data/recently_watched.json')
    
    if name in data:
        del data[name]
        with open(fp, 'w', encoding='utf8') as f:
            json.dump(data, f)
