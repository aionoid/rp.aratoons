# -*- coding: utf-8 -*-

import os
import json

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import six
from six.moves import urllib_parse

try:
    import md5
except ImportError:
    from hashlib import md5

from lib.constants import PLUGIN_URL, RESOURCE_URL, KODI_VERSION, BASEURL, WNT2_USER_AGENT, ADDON_ICON, PROPERTY_SESSION_COOKIE

import re

ADDON = xbmcaddon.Addon()

def getWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    data = window.getProperty(prop)
    return json.loads(data) if data else None

def setWindowProperty(prop, data):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    temp = json.dumps(data)
    window.setProperty(prop, temp)

def clearWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    window.clearProperty(prop)

def testWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return window.getProperty(prop) != ''

def getRawWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return window.getProperty(prop)

def setRawWindowProperty(prop, data):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    window.setProperty(prop, data)

def setViewMode():
    if ADDON.getSetting('useViewMode') == 'true':
        view_mode_id = ADDON.getSetting('viewModeID')
        if view_mode_id.isdigit():
            xbmc.executebuiltin('Container.SetViewMode(' + view_mode_id + ')')

def unescapeHTMLText(text):

    """
    Unescape HTML entities.
    Strings found by regex-searching on all lists in the source website.
    It's very likely to only be these.
    """

    if isinstance(text, six.text_type) and six.PY2:
        text = text.encode('utf-8')

    if r'&' in text:
        text = text.replace(r'&amp;', '&').replace(r'&quot;', '"').replace(r'&apos;', "'")

        if r'&#' in text:
            text = text.replace(r'&#038;', '&').replace(r'&#039;', '’').replace(r'&#160;', ' ') \
                .replace(r'&#8211;', '–').replace(r'&#8216;', '‘').replace(r'&#8217;', '’') \
                .replace(r'&#8220;', '“').replace(r'&#8221;', '”').replace(r'&#8230;', '…')

            # Handle any remaining numeric entities (e.g. &#215; → ×)
            text = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), text)

    return text.replace('\u2606', ' ')

def base_url_remove(base_url, url):

    """ensures the base URL is removed from a URL"""

    if url.startswith(base_url):
        url = url.replace(base_url, '', 1)

    return url

def ensure_url_schema(url):

    """returns a url that has https"""

    if url:
        if url.startswith('//'):
            return 'https:' + url

    return url


def ensure_full_url( url, base_url ):

    """ returns a full url """

    if url.startswith( 'http' ):
        return url
    return base_url + url


def ensure_current_domain( url, domain, domains ):

    """ returns a full url with the current domain """

    url = ensure_full_url( 'https://' + domain, url )
    for d in domains:
        if d in url:
            return url.replace( d, domain, 1 )

    return url


def xbmc_debug(*args):

    """used for debugging"""

    xbmc.log(
        'StarDima > ' + ' '.join((val if isinstance(val, str) else repr(val)) for val in args),
        xbmc.LOGWARNING
    )

def item_set_info(line_item, properties):

    """
    line item set info
    Fix listitem deprecated warnings
    """

    if KODI_VERSION > 19.8:
        vidtag = line_item.getVideoInfoTag()
        if properties.get('title'):
            vidtag.setTitle(properties.get('title'))
        if properties.get('plot'):
            vidtag.setPlot(properties.get('plot'))
        if properties.get('tvshowtitle'):
            vidtag.setTvShowTitle(properties.get('tvshowtitle'))
        if properties.get('season'):
            vidtag.setSeason(properties.get('season'))
        if properties.get('episode'):
            vidtag.setEpisode(properties.get('episode'))
        if properties.get('mediatype'):
            vidtag.setMediaType(properties.get('mediatype'))
    else:
        line_item.setInfo('video', properties)

def translate_path(path):

    """
    method to translate path for both PY2 & PY3
    stops all the if else statements
    """

    if six.PY2:
        return xbmc.translatePath(path)
    return xbmcvfs.translatePath(path)

def ensure_path_exists(path):

    """creates path if doesn't exist"""

    addon_data_path = translate_path(path)

    if os.path.exists(addon_data_path) is False:
        os.mkdir(addon_data_path)
        xbmc.sleep(1)
        return True

    return False

def generate_md5(str_to_md5):

    """generates a MD5 hash"""

    if six.PY2:
        md5_instance = md5.new()
    else:
        md5_instance = md5()
        str_to_md5 = bytes(str_to_md5, 'UTF-8')

    md5_instance.update(str_to_md5)
    return md5_instance.hexdigest()

def build_url(query):

    """
    Helper function to build a Kodi xbmcgui.ListItem URL.
    :param query: Dictionary of url parameters to put in the URL.
    :returns: A formatted and urlencoded URL string.
    """

    return PLUGIN_URL + '?' + \
        urllib_parse.urlencode({k: v.encode('utf-8') if isinstance(v, six.text_type)
            else unicode(v, errors='ignore').encode('utf-8')
            for k, v in query.items()})

def file_read(path):

    """reads file's contents"""

    if six.PY2:
        return open(path, 'r')

    return open(path, 'r', encoding='utf8')

def file_write(path, content):

    """writes file's contents"""

    if six.PY2:
        file_str = open(path, 'w')
        file_str.write(content)
        file_str.close()
        return True

    with open(path, 'w', encoding='utf8') as file_str:
        file_str.write(content)
        file_str.close()
        return True

def hash_file_get(path, file_dir='thumbnail'):

    """gets required hash file"""

    hashes = file_read(
        translate_path(RESOURCE_URL + 'data/' + file_dir + '/' + path.replace('/', '') + '.json')
    )

    if hashes:
        return json.load(hashes)

    return {}

def quality_label(quality):

    """Retrieves label based upon quality"""

    if quality >= 1080:
        return '1080 (FHD)'
    if quality >= 720:
        return '720 (HD)'
    return '480 (SD)'

def thumb_path_get(hash_value):

    """Convert a cached thumbnail hash to a local file path"""

    if not hash_value:
        return ''

    thumb_base = translate_path(RESOURCE_URL + 'data/thumbnail/')
    return thumb_base + hash_value + '.jpg'

def get_thumbnail_headers():

    """Thumbnail HTTP headers for Kodi to use when grabbing thumbnail images."""

    cookie_property = getRawWindowProperty(PROPERTY_SESSION_COOKIE)
    cookies = ('&Cookie=' + urllib_parse.quote_plus(cookie_property)) if cookie_property else ''

    return '|User-Agent=' + urllib_parse.quote_plus(WNT2_USER_AGENT) + \
        '&Accept=image%2Fwebp%2C%2A%2F%2A&Referer=' + \
        urllib_parse.quote_plus(BASEURL + '/') + cookies


def getPageMetadata(html):

    """
    If we're on an episode or (old) movie page,
    see if there's a parent page with the actual metadata.
    """

    from lib.sites.stardima import SITE_SETTINGS

    string_start_index = html.find(SITE_SETTINGS['page_meta']['start'])
    if string_start_index != -1:
        parent_url = re.search(SITE_SETTINGS['page_meta']['regex'], html[string_start_index:]).group(1)
        if '/anime/movies' not in parent_url:
            from lib.network import request_helper
            r = request_helper(ensure_full_url(BASEURL, parent_url))
            if r.ok:
                html = r.text

    # Thumbnail scraping.
    thumb = ''
    string_start_index = html.find(SITE_SETTINGS['thumbnail']['start'])
    if string_start_index != -1:
        # 19 = len('og:image" content="')
        thumb = html[string_start_index + 19: html.find('"', string_start_index + 19)]
        thumb = ensure_full_url(BASEURL, thumb)
        # add headers
        thumb += get_thumbnail_headers()

    if thumb:
        # animationexplore seems more reliable
        thumb = thumb.replace(BASEURL + '/wp-content', BASEURL)

    # The shows plot scraping.
    plot = ''
    string_start_index = html.find(SITE_SETTINGS['page_plot']['start'])
    if string_start_index != -1:
        match = re.search(SITE_SETTINGS['page_plot']['regex'], html[string_start_index:], re.DOTALL)
        plot = unescapeHTMLText(match.group(1).strip()) if match else ''

    return plot, thumb


def get_title_info(unescaped_title):

    """
    We need to interpret the full title of each episode's link's string
    for information like episode number, season and show title.
    """

    season = None
    episode = None
    multi_part = None
    show_title = unescaped_title
    episode_title = ''

    seasonIndex = unescaped_title.find('Season ')  # 7 characters long.
    if seasonIndex != -1:
        season = unescaped_title[seasonIndex + 7: unescaped_title.find(' ', seasonIndex + 7)]
        if not season.isdigit():
            # Handle inconsistently formatted episode title, with possibly ordinal season
            # before or after the word "Season" (case unknown, inconsistent).
            if season == 'Episode':
                # Find the word to the left of "Season ",
                # separated by spaces (spaces not included in the result).
                season = unescaped_title[unescaped_title.rfind(' ', 0, seasonIndex - 1) + 1: seasonIndex - 1]
                # Include the "nth Season" term in the title.
                show_title = unescaped_title[:seasonIndex + 7].strip(' -–:')
            else:
                show_title = unescaped_title[:seasonIndex].strip(' -–:')
            season = {'second': '2', 'third': '3', 'fourth': '4', 'fifth': '5'}.get(season.lower(), '')
        else:
            show_title = unescaped_title[:seasonIndex].strip(' -–:')

    episode_index = unescaped_title.find(' Episode ')  # 9 characters long.

    if episode_index != -1:
        space_index = unescaped_title.find(' ', episode_index + 9)
        if space_index > episode_index:
            # For multi_part episodes, like "42-43".
            episode_split = unescaped_title[episode_index + 9: space_index].split('-')
            episode = filter(str.isdigit, episode_split[0])
            multi_part = filter(str.isdigit, episode_split[1]) if len(episode_split) > 1 else None

            # Get the episode title string (stripped of spaces, hyphens and en-dashes).
            english_index = unescaped_title.rfind(' English', space_index)
            if english_index != -1:
                episode_title = unescaped_title[space_index + 1: english_index].strip(' -–:')
            else:
                episode_title = unescaped_title[space_index + 1:].strip(' -–:')
            # Safeguard for when season 1 is occasionally omitted in the title.
            if not season:
                season = '1'

    if episode:
        return (show_title[:episode_index].strip(' -'), season, episode, multi_part, episode_title.strip(' /'))

    english_index = unescaped_title.rfind(' English')
    if english_index != -1:
        return (unescaped_title[:english_index].strip(' -'), None, None, None, '')

    return (unescaped_title.strip(' -'), None, None, None, '')


def makeListItem(title, url, art_dict, plot, is_folder, is_special, oldParams, isRecent=False):

    unescaped_title = unescapeHTMLText(title)
    plot = unescapeHTMLText(plot)
    item = xbmcgui.ListItem(unescaped_title)
    is_playable = False

    if not (is_folder or is_special):
        title, season, episode, multi_part, episode_title = get_title_info(unescaped_title)
        # Playable content.
        is_playable = True
        item_info = {
            'mediatype': 'episode' if episode else 'tvshow',
            'tvshowtitle': title,
            'title': episode_title,
            'plot': plot
        }

        if six.PY3:
            episode = str(episode)

        if episode and episode.isdigit():
            item_info['season'] = int(season) if season.isdigit() else -1
            item_info['episode'] = int(episode)

        item_set_info(item, item_info)

    elif is_special:
        is_playable = True
        item_set_info(item, {'mediatype': 'movie', 'title': unescaped_title, 'plot': plot})
    else:
        item_set_info(item, {'mediatype': 'tvshow', 'title': unescaped_title, 'plot': plot})

    if art_dict:
        item.setArt(art_dict)

    # Add the context menu items, if necessary.
    context_menu_list = []
    if oldParams:
        context_menu_list.append(
            (
                'StarDima Information',
                'RunPlugin(' + PLUGIN_URL + '?action=actionShowInfo&url=' + urllib_parse.quote_plus(url) +
                '&oldParams=' + urllib_parse.quote_plus(urllib_parse.urlencode(oldParams)) + ')'
            )
        )

    if is_playable:
        # Allows the checkmark to be placed on watched episodes.
        item.setProperty('IsPlayable', 'true')
        # add content menu to play chapters
        context_menu_list.append(
            (
                'Play Chapters',
                'PlayMedia(' + PLUGIN_URL + '?action=actionResolve&url=' + urllib_parse.quote_plus(url) +
                '&playChapters=1)'
            )
        )
    if isRecent:
        # So item can be removed
        context_menu_list.append(
            (
                'Remove',
                'PlayMedia(' + PLUGIN_URL + '?action=actionRecentlyWatchedRemove&url=' + urllib_parse.quote_plus(url) + ')'
            )
        )

    if context_menu_list:
        item.addContextMenuItems(context_menu_list)

    return item


def makeListItemClean(title, url, art_dict, plot, is_folder, is_special, oldParams):

    """
    Variant of the 'makeListItem()' function
    tries to format the item label using the season and episode.
    """

    unescaped_title = unescapeHTMLText(title)
    plot = unescapeHTMLText(plot)
    is_playable = False

    if is_folder or is_special:
        item = xbmcgui.ListItem(unescaped_title)
        if is_special:
            is_playable = True
            item_set_info(item, {'mediatype': 'video', 'title': unescaped_title})
    else:
        title, season, episode, multi_part, episode_title = get_title_info(unescaped_title)

        # dirty way to ensure is a string
        # this is due to filters being used, todo for clean-up
        if six.PY3:
            if episode:
                episode = "".join(episode)
            if season:
                season = "".join(season)
            if multi_part:
                multi_part = "".join(multi_part)

        if episode and episode.isdigit():
            # The clean episode label will have this format:
            # "SxEE Episode Name", with S and EE standing for digits.
            item = xbmcgui.ListItem(
                '[B]' + season + 'x' + episode.zfill(2) + ('-' + multi_part if multi_part else '') + '[/B] '
                + (episode_title or title)
            )
            item_info = {
                'mediatype': 'episode',
                'tvshowtitle': title,
                'title': title,
                'plot': plot,
                'season': int(season) if season.isdigit() else -1,
                'episode': int(episode)
            }
        else:
            item = xbmcgui.ListItem(title)
            item_info = {
                'mediatype': 'tvshow',
                'tvshowtitle': title,
                'title': title,
                'plot': plot
            }
        item_set_info(item, item_info)
        is_playable = True

    if art_dict:
        item.setArt(art_dict)

    # Add the context menu items, if necessary.
    context_menu_list = []
    if oldParams:
        context_menu_list.append(
            (
                'Show Information',
                'RunPlugin(' + PLUGIN_URL + '?action=actionShowInfo&url=' + urllib_parse.quote_plus(url) +
                '&oldParams=' + urllib_parse.quote_plus(urllib_parse.urlencode(oldParams)) + ')'
            )
        )
    if is_playable:
        # Allows the checkmark to be placed on watched episodes.
        item.setProperty('IsPlayable', 'true')
        # add content menu to play chapters
        context_menu_list.append(
            (
                'Play Chapters',
                'PlayMedia(' + PLUGIN_URL + '?action=actionResolve&url=' + urllib_parse.quote_plus(url) +
                '&playChapters=1)'
            )
        )

    if context_menu_list:
        item.addContextMenuItems(context_menu_list)

    return item


if six.PY3:
    xrange = range
