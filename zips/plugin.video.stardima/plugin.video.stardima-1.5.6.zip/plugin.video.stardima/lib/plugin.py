# -*- coding: utf-8 -*-

import re
import sys
import json
import uuid
import time
import six
from itertools import chain
from string import ascii_uppercase

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from lib.constants import *
from lib.common import *
from lib.network import rqs_get, request_helper
from lib.recently_watched import recently_watched_load, recently_watched_add, recently_watched_remove

from lib.sites.stardima import *

def site_domains_get():
    """Returns possible site domains."""
    return ('www.stardima.com',)

__language__ = ADDON.getLocalizedString

def actionMenu(params):
    def _menuItem(title, data, color):
        item = xbmcgui.ListItem('[B][COLOR ' + color + ']' + title + '[/COLOR][/B]', label2=title)
        item.setArt(ADDON_ICON_DICT)
        item_set_info(item, {'title': title, 'plot': title})
        return (build_url(data), item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, (
        _menuItem(__language__(30051), {'action': 'actionCatalogMenu', 'path': URL_PATHS['latest_episodes']}, 'mediumaquamarine'),
        _menuItem(__language__(30052), {'action': 'actionCatalogMenu', 'path': URL_PATHS['latest_movies']}, 'mediumaquamarine'),
        _menuItem(__language__(30053), {'action': 'actionCatalogMenu', 'path': URL_PATHS['latest_series']}, 'mediumaquamarine'),
        _menuItem(__language__(30054), {'action': 'actionMoviesMenu'}, 'mediumaquamarine'),
        _menuItem(__language__(30055), {'action': 'actionSeriesMenu'}, 'mediumaquamarine'),
        _menuItem(__language__(30066), {'action': 'actionKidsTVMenu'}, 'lightcoral'),
        _menuItem(xbmc.getLocalizedString(137), {'action': 'actionSearchMenu', 'path': 'search'}, 'lavender'),
        _menuItem(xbmc.getLocalizedString(1390), {'action': 'actionShowSettings', 'path': 'settings'}, 'lavender'),
    ))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def actionKidsTVMenu(params):
    """Kids TV Channels from elahmad.ru."""
    xbmcplugin.setContent(PLUGIN_ID, 'tvshows')

    from lib.sites import elahmad

    channels = elahmad.get_kids_channels()

    items = []
    for ch_url, ch_title, ch_poster in channels:
        art = dict(ADDON_ICON_DICT)
        if ch_poster:
            art['thumb'] = ch_poster
            art['poster'] = ch_poster
        item = makeListItem(unescapeHTMLText(ch_title), ch_url, art, '', is_folder=False, is_special=False, oldParams=None)
        items.append((build_url({'action': 'actionKidsTVPlay', 'url': ch_url}), item, False))

    # Add "Back to Home"
    home_item = xbmcgui.ListItem('[B][COLOR mediumaquamarine]\u2190 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629[/COLOR][/B]')
    home_item.setArt(ADDON_ICON_DICT)
    items.insert(0, (build_url({'action': 'actionMenu'}), home_item, True))

    xbmcplugin.addDirectoryItems(PLUGIN_ID, items)
    xbmcplugin.endOfDirectory(PLUGIN_ID)
    setViewMode()


def actionKidsTVPlay(params):
    """Play a Kids TV channel stream."""
    channel_url = params['url']

    from lib.sites import elahmad

    result = elahmad.resolve_channel_stream(channel_url)
    if not result:
        xbmcgui.Dialog().ok(PLUGIN_TITLE, 'Unable to get stream')
        return

    # Determine Kids TV playback method (0 = use global, 1-8 = specific)
    kids_playback = ADDON.getSetting('kidsTVPlaybackMethod')
    playback_override = None
    if kids_playback != '0':
        playback_override = kids_playback

    # DASH + clearkey DRM (dict result)
    if isinstance(result, dict):
        mpd_url = result['mpd_url']
        clearkey = result.get('clearkey', {})
        referer = 'https://www.elahmad.ru/'
        _play_media(mpd_url, is_m3u8=False, referer=referer, clearkey=clearkey, playback_method=playback_override)
        return

    # HLS stream (str result)
    stream_url = result
    is_m3u8 = '.m3u8' in stream_url
    # NOTE: Do NOT send Referer for elahmad streams. The CDN (edgenextcdn.net)
    # returns 403 when any Referer header is present on segment requests.
    _play_media(stream_url, is_m3u8, referer=None, playback_method=playback_override)


def actionMoviesMenu(params):
    """Movies sub-menu: All, Subtitled, Dubbed."""
    def _menuItem(title, data, color):
        item = xbmcgui.ListItem('[B][COLOR ' + color + ']' + title + '[/COLOR][/B]', label2=title)
        item.setArt(ADDON_ICON_DICT)
        item_set_info(item, {'title': title, 'plot': title})
        return (build_url(data), item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, (
        _menuItem(__language__(30054), {'action': 'actionCatalogMenu', 'path': URL_PATHS['movies']}, 'mediumaquamarine'),
        _menuItem(__language__(30058), {'action': 'actionCatalogMenu', 'path': URL_PATHS['movies_sub']}, 'lightyellow'),
        _menuItem(__language__(30059), {'action': 'actionCatalogMenu', 'path': URL_PATHS['movies_dub']}, 'lightyellow'),
    ))
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def actionSeriesMenu(params):
    """Series sub-menu: All, Subtitled, Dubbed."""
    def _menuItem(title, data, color):
        item = xbmcgui.ListItem('[B][COLOR ' + color + ']' + title + '[/COLOR][/B]', label2=title)
        item.setArt(ADDON_ICON_DICT)
        item_set_info(item, {'title': title, 'plot': title})
        return (build_url(data), item, True)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, (
        _menuItem(__language__(30055), {'action': 'actionCatalogMenu', 'path': URL_PATHS['series']}, 'mediumaquamarine'),
        _menuItem(__language__(30058), {'action': 'actionCatalogMenu', 'path': URL_PATHS['series_sub']}, 'lightyellow'),
        _menuItem(__language__(30059), {'action': 'actionCatalogMenu', 'path': URL_PATHS['series_dub']}, 'lightyellow'),
    ))
    xbmcplugin.endOfDirectory(PLUGIN_ID)

def actionCatalogMenu(params):
    xbmcplugin.setContent(PLUGIN_ID, 'tvshows')
    path = params['path']
    page = int(params.get('page', 1))

    # Fetch a single page via JSON API (faster, more reliable than HTML scraping)
    from lib.sites.stardima import _catalog_api_paginated, _scrape_newreleases_by_tab
    from lib.common import unescapeHTMLText

    is_latest_episodes = path == URL_PATHS['latest_episodes']
    is_latest_movies = path == URL_PATHS['latest_movies']
    is_latest_series = path == URL_PATHS['latest_series']

    if is_latest_episodes or is_latest_movies or is_latest_series:
        # /newrelases has no pagination — scrape tabs and pick the right one
        catalog = _scrape_newreleases_by_tab()
        if is_latest_episodes:
            items_page = list(catalog['NewEpisodes'])
        elif is_latest_movies:
            items_page = list(catalog['NewMovies'])
        else:
            items_page = list(catalog['NewSeries'])
        last_page = 1
    else:
        result = _catalog_api_paginated(path, page=page)
        items_page = result['items']
        last_page = result['last_page']

    art_dict = ADDON_ICON_DICT

    def _itemGen():
        for entry_url, entry_title, entry_poster in items_page:
            entry_art = dict(art_dict)
            if entry_poster:
                entry_art['thumb'] = entry_poster
                entry_art['poster'] = entry_poster
            entry_url_rel = base_url_remove(BASEURL, entry_url)
            if '/play/' in entry_url:
                action, is_folder = 'actionResolve', False
            elif '/movie/' in entry_url:
                action, is_folder = 'actionResolve', False
            else:
                action, is_folder = 'actionEpisodesMenu', True
            yield (build_url({'action': action, 'url': entry_url_rel,
                              'path': path, 'page': str(page)}),
                   makeListItem(unescapeHTMLText(entry_title), entry_url_rel,
                                entry_art, '', is_folder, not is_folder,
                                {'action': action, 'url': entry_url_rel}),
                   is_folder)

    items = list(_itemGen())

    # Add "Back to Home" button
    home_item = xbmcgui.ListItem('[B][COLOR mediumaquamarine]← الرئيسية[/COLOR][/B]')
    home_item.setArt(ADDON_ICON_DICT)
    home_url = build_url({'action': 'actionMenu'})
    items.insert(0, (home_url, home_item, True))

    # Add "Next Page" if more pages available
    if last_page > 1 and page < last_page:
        pages_left = last_page - page
        next_item = xbmcgui.ListItem('[B]Page ' + str(page + 1) + ' / ' + str(last_page) + ' (' + str(pages_left) + ' left)[/B]')
        next_item.setArt(ADDON_ICON_DICT)
        next_url = build_url({'action': 'actionCatalogMenu', 'path': path, 'page': str(page + 1)})
        items.append((next_url, next_item, True))

    xbmcplugin.addDirectoryItems(PLUGIN_ID, items)
    xbmcplugin.endOfDirectory(PLUGIN_ID)
    setViewMode()

def actionCatalogSection(params):
    """Redirect to actionCatalogMenu (pagination replaces catalog sections)."""
    params.setdefault('section', 'ALL')
    actionCatalogMenu(params)

def actionEpisodesMenu(params):
    xbmcplugin.setContent(PLUGIN_ID, 'episodes')

    url = params['url']
    url = base_url_remove(BASEURL, url)

    # Parse series slug from URL: /tvshow/{slug}
    series_slug = url.replace('/tvshow/', '', 1).split('/')[0]

    lastListURL = getRawWindowProperty(PROPERTY_EPISODE_LIST_URL)
    if lastListURL and lastListURL == params['url']:
        listData = getWindowProperty(PROPERTY_EPISODE_LIST_DATA)
    else:
        # Get seasons and episodes via StarDima API
        from lib.sites.stardima import _get_seasons, _get_episodes
        seasons_data = _get_seasons(series_slug)
        thumb = seasons_data.get('poster', '')
        plot = seasons_data.get('description', '')

        all_episodes = []
        for season_id in seasons_data.get('seasons', []):
            ep_data = _get_episodes(season_id)
            for ep in ep_data.get('episodes', []):
                ep_url = '/tvshow/' + series_slug + '/play/' + str(ep['id'])
                all_episodes.append((ep_url, ep['title'], ''))

        listData = (thumb, plot, tuple(all_episodes))
        setRawWindowProperty(PROPERTY_EPISODE_LIST_URL, params['url'])
        setWindowProperty(PROPERTY_EPISODE_LIST_DATA, listData)

    def _episodeItemsGen():
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()

        art_dict = ADDON_ICON_DICT
        thumb = listData[0]
        if thumb:
            art_dict = {'icon': thumb, 'thumb': thumb, 'poster': thumb}

        plot = listData[1]
        listItemFunc = makeListItemClean if ADDON.getSetting('cleanupEpisodes') == 'true' else makeListItem

        item_params = {'action': 'actionResolve', 'url': None}

        listIter = iter(listData[2]) if ADDON.getSetting('reverseEpisodes') == 'false' else reversed(listData[2])

        for url, title, episode_type in listIter:
            show_type = re.search(r'lang=(dub|sub)', params['url'])
            if show_type:
                show_type = str(show_type.group(1))
                if episode_type and episode_type in LANG_TYPES and episode_type != show_type:
                    continue

            if ADDON_VIDEO_FANART:
                art_dict['fanart'] = url.replace(BASEURL, IMAGES_URL + '/thumbnails') + '.jpg'

            url = base_url_remove(BASEURL, url)
            item = listItemFunc(title, url, art_dict, plot, is_folder=False, is_special=False, oldParams=None)
            item_params['url'] = url
            item_url = build_url(item_params)
            playlist.add(item_url, item)
            yield (item_url, item, False)

    xbmcplugin.addDirectoryItems(PLUGIN_ID, tuple(_episodeItemsGen()))
    xbmcplugin.endOfDirectory(PLUGIN_ID)

def actionLatestMoviesMenu(params):
    """Redirect to actionCatalogMenu for /aflam (pagination handles it)."""
    params.setdefault('path', URL_PATHS['movies'])
    actionCatalogMenu(params)

def actionSearchMenu(params):
    """Search using StarDima JSON API with pagination."""
    query = params.get('query', '')
    page = int(params.get('page', 1))

    if not query:
        # Show keyboard
        kb = xbmc.Keyboard('', 'Search')
        kb.doModal()
        query = kb.getText()
        if not query:
            xbmcplugin.endOfDirectory(PLUGIN_ID)
            return
        page = 1

    from lib.sites.stardima import _search_api
    data = _search_api(query, page=page)
    results = data['results']
    last_page = data['last_page']

    items = []
    for r in results:
        art_dict = ADDON_ICON_DICT
        if r.get('poster_url'):
            art_dict['thumb'] = r['poster_url']
            art_dict['poster'] = r['poster_url']
        entry_url = base_url_remove(BASEURL, r['url'])
        entry_title = r['title']
        action = 'actionEpisodesMenu' if r.get('is_series') else 'actionResolve'
        is_folder = r.get('is_series', False)
        item_params = {'action': action, 'url': entry_url}
        item = makeListItem(entry_title, entry_url, art_dict, '',
                            is_folder=is_folder, is_special=not is_folder, oldParams=item_params)
        items.append((build_url(item_params), item, is_folder))

    # Add "Next Page" if more pages
    if page < last_page:
        pages_left = last_page - page
        next_item = xbmcgui.ListItem('[B]Page ' + str(page + 1) + ' / ' + str(last_page) + ' (' + str(pages_left) + ' left)[/B]')
        next_item.setArt(ADDON_ICON_DICT)
        next_url = build_url({'action': 'actionSearchMenu', 'query': query, 'page': str(page + 1)})
        items.append((next_url, next_item, True))

    xbmcplugin.addDirectoryItems(PLUGIN_ID, items)
    setViewMode()
    xbmcplugin.endOfDirectory(PLUGIN_ID)

def catalogFromIterable(iterable):
    """Manually sorts items from an iterable into an alphabetised catalog."""
    catalog = {key: [] for key in ascii_uppercase}
    misc_section = catalog['#'] = []
    for item in iterable:
        key = item[1][0].upper() if item[1] else '#'
        if key in catalog:
            catalog[key].append(item)
        else:
            misc_section.append(item)
    return catalog


def makeSeriesSearchCatalog(params):
    """Use StarDima JSON search API for series (single page)."""
    from lib.sites.stardima import _search_api
    page = int(params.get('page', 1))
    data = _search_api(params['query'], page=page)
    results = data['results']
    items = []
    for r in results:
        if r.get('is_series'):
            items.append((r['url'], r['title'], r.get('poster_url', '')))
    return catalogFromIterable(items)


def makeMoviesSearchCatalog(params):
    """Use StarDima JSON search API for movies (single page)."""
    from lib.sites.stardima import _search_api
    page = int(params.get('page', 1))
    data = _search_api(params['query'], page=page)
    results = data['results']
    items = []
    for r in results:
        if not r.get('is_series'):
            items.append((r['url'], r['title'], r.get('poster_url', '')))
    return catalogFromIterable(items)


def makeEpisodesSearchCatalog(params):
    """Search episodes (not implemented for StarDima)."""
    return {'#': []}


def makeSearchCatalog(params):
    search_type = params.get('searchType', 'series')
    if search_type == 'series':
        return makeSeriesSearchCatalog(params)
    if search_type == 'movies':
        return makeMoviesSearchCatalog(params)
    return makeEpisodesSearchCatalog(params)


def makeGenericCatalog(params):
    """Scrape single page for backward compatibility."""
    from lib.sites.stardima import _scrape_catalog_paginated
    page = int(params.get('page', 1))
    result = _scrape_catalog_paginated(params['path'], page=page)
    if not result['items']:
        raise Exception('Generic catalog scrape fail: ' + params['path'])
    return catalogFromIterable(result['items'])


CATALOG_FUNCS = {
    URL_PATHS['search']: makeSearchCatalog,
}


def getCatalogProperty(params):
    """Retrieves the catalog from a persistent XBMC window property or recreates it."""
    path = params['path']

    def _rebuildCatalog():
        func = CATALOG_FUNCS.get(path, makeGenericCatalog)
        catalog = func(params)
        setWindowProperty(PROPERTY_CATALOG, catalog)
        if 'query' in params:
            setRawWindowProperty(PROPERTY_CATALOG_PATH, path + params['query'] + params['searchType'])
        else:
            setRawWindowProperty(PROPERTY_CATALOG_PATH, path)
        setRawWindowProperty(PROPERTY_INFO_ITEMS, '')
        return catalog

    current_path = getRawWindowProperty(PROPERTY_CATALOG_PATH)
    if (
        ('query' in params and (params['query'] not in current_path or params['searchType'] not in current_path))
        or ('query' not in params and current_path != path)
    ):
        catalog = _rebuildCatalog()
    else:
        catalog = getWindowProperty(PROPERTY_CATALOG)
        if not catalog:
            catalog = _rebuildCatalog()
    return catalog

def actionRecentlyWatchedRemove(params):
    """Removes from recently watched."""
    if recently_watched_remove(params['url']):
        xbmcgui.Dialog().notification(
            PLUGIN_TITLE, 'Removed from recently watched', xbmcgui.NOTIFICATION_INFO, 3000, True
        )
    return


def actionShowSettings(params):
    ADDON.openSettings()
    global ADDON_SHOW_CATALOG
    ADDON_SHOW_CATALOG = ADDON.getSetting('showCatalog') == 'true'
    global ADDON_LATEST_DATE
    newLatestDate = ADDON.getSetting('useLatestDate') == 'true'
    if ADDON_LATEST_DATE != newLatestDate:
        setRawWindowProperty(PROPERTY_CATALOG_PATH, '')
    ADDON_LATEST_DATE = newLatestDate
    global ADDON_LATEST_THUMBS
    ADDON_LATEST_THUMBS = ADDON.getSetting('showLatestThumbs') == 'true'
    xbmcplugin.endOfDirectory(PLUGIN_ID)


def actionShowInfo(params):
    xbmcgui.Dialog().notification(PLUGIN_TITLE, 'Requesting info...', ADDON_ICON, 2000, False)
    url = params['url'].replace('/m.', '/www.', 1)
    r = request_helper(ensure_full_url(BASEURL, url))
    html = r.text
    plot, thumb = getPageMetadata(html)
    if plot or thumb:
        info_items = getWindowProperty(PROPERTY_INFO_ITEMS) or {}
        info_items[url] = (plot, (thumb or 'DefaultVideo.png'))
        setWindowProperty(PROPERTY_INFO_ITEMS, info_items)
        xbmc.executebuiltin('Container.Update(%s,replace)' % (PLUGIN_URL + '?' + params['oldParams']))
    else:
        xbmcgui.Dialog().notification(PLUGIN_TITLE, 'No info found', ADDON_ICON, 1500, False)


def actionResolve(params):
    """Resolve episode/movie to playable stream URL with server selection."""
    url = params['url']
    if not url.startswith('http'):
        url = BASEURL + url

    from lib.sites.stardima import resolve_stardima_stream, get_stardima_servers

    # Get available servers
    servers = get_stardima_servers(url)
    if not servers:
        xbmcgui.Dialog().ok(PLUGIN_TITLE, 'Unable to find available servers')
        return

    # Show server selection menu
    labels = [s['label'] for s in servers]
    selected = xbmcgui.Dialog().select(__language__(30200), labels)  # "Select Server"

    if selected < 0:
        return  # User cancelled

    selected_server = servers[selected]['name']
    result = resolve_stardima_stream(url, server_name=selected_server)

    if not result:
        xbmcgui.Dialog().ok(PLUGIN_TITLE,
                           f'Unable to get stream from {selected_server}')
        return

    stream_url, referer = result
    is_m3u8 = '.m3u8' in stream_url or stream_url.endswith('.txt') or 'master.txt' in stream_url
    # Detect servers that need inputstream.ffmpegdirect instead of
    # inputstream.adaptive. These servers return HLS playlists that
    # inputstream.adaptive struggles with (media playlists, CDN auth, etc.).
    use_ffmpegdirect = False
    if is_m3u8:
        earnvids_domains = ('dramiyos-cdn.com', 'acek-cdn.com')
        uqload_domains = ('uqload.is', 'strm2.uqload.is', 'lulustream.com', 'lulucdn.net')
        if any(d in stream_url for d in earnvids_domains + uqload_domains):
            use_ffmpegdirect = True
            is_m3u8 = False  # Don't use inputstream.adaptive
    _play_media(stream_url, is_m3u8, referer, ffmpegdirect=use_ffmpegdirect)


def get_thumbnail_headers():
    cookie_property = getRawWindowProperty(PROPERTY_SESSION_COOKIE)
    cookies = ('&Cookie=' + urllib_parse.quote_plus(cookie_property)) if cookie_property else ''
    return '|User-Agent=' + urllib_parse.quote_plus(WNT2_USER_AGENT) + \
        '&Accept=image%2Fwebp%2C%2A%2F%2A&Referer=' + urllib_parse.quote_plus(BASEURL + '/') + cookies


def _play_media(media_url, is_m3u8, referer=None, clearkey=None, playback_method=None, ffmpegdirect=False):
    """Common playback logic for resolved streams.

    Args:
        media_url: stream URL (m3u8 or mpd)
        is_m3u8: True for HLS, False for DASH/other
        referer: referer URL string or dict of extra headers
        clearkey: dict of {kid: key} for DASH clearkey DRM
        playback_method: override playbackMethod setting (0-7), or None for global
    """
    log = lambda msg: xbmc.log('AraToons (plugin): {}'.format(msg), xbmc.LOGDEBUG)
    import urllib.parse as urllib_parse

    headers = {
        'User-Agent': WNT2_USER_AGENT,
        'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
    }

    stream_url = media_url
    if ADDON.getSetting('useHTTP') == 'true':
        stream_url = stream_url.replace('https://', 'http://', 1)

    # Determine playback method
    playback = playback_method if playback_method is not None else ADDON.getSetting('playbackMethod')  # '0' = ask, '1' = adaptive, '2' = 1080p, etc.

    resolved_stream = stream_url

    item = xbmcgui.ListItem(xbmc.getInfoLabel('ListItem.Label'))
    if is_m3u8:
        item.setPath(resolved_stream)
        item.setContentLookup(False)
        item.setMimeType('application/x-mpegURL')
        ips = 'inputstream.adaptive'
        item.setProperty(ips, ips)
        item.setProperty('#KODIPROP:inputstream', ips)
        if referer:
            # referer can be a string (Referer URL) or dict with Referer + Cookie
            if isinstance(referer, dict):
                headers.update(referer)
            else:
                headers['Referer'] = referer
                headers['Origin'] = referer.rsplit('/', 1)[0]
        headers_str = '&'.join(k + '=' + urllib_parse.quote_plus(v) for k, v in headers.items())
        item.setProperty(ips + '.stream_headers', headers_str)
        item.setProperty(ips + '.manifest_headers', headers_str)
        item.setProperty(ips + '.stream_params', headers_str)
        item.setProperty(ips + '.license_key', 'n/a')
        item.setProperty(ips + '.allow_crypto', 'true')
        item.setProperty(ips + '.assumewebheaderstos', 'true')
        item.setProperty(ips + '.manifest_type', 'hls')
        item.setProperty(ips + '.original_audio_language', 'en')
        if playback == '0':
            item.setProperty(ips + '.stream_selection_type', 'ask-quality')
        elif playback == '1':
            item.setProperty(ips + '.stream_selection_type', 'adaptive')
        else:
            # Resolution preset: use adaptive but set preferred height
            item.setProperty(ips + '.stream_selection_type', 'adaptive')
            target_height = int(playback) - 2  # 2=1080, 3=720, 4=576, 5=468, 6=360, 7=288
            target_heights = [1080, 720, 576, 468, 360, 288]
            if 0 <= target_height < len(target_heights):
                h = target_heights[target_height]
                item.setProperty(ips + '.preferred_video_resolution', str(h))
    elif ffmpegdirect:
        # HLS media playlist via inputstream.ffmpegdirect
        # Used for servers like Earnvids, Uqload, Lulustream — inputstream.adaptive
        # cannot handle their HLS playlists properly (media playlists without
        # #EXT-X-STREAM-INF, CDN auth issues, etc.). ffmpegdirect handles them
        # natively via FFmpeg's libavformat.
        item.setPath(stream_url)
        item.setContentLookup(False)
        item.setMimeType('application/x-mpegURL')
        ips = 'inputstream.ffmpegdirect'
        item.setProperty(ips, ips)
        item.setProperty('#KODIPROP:inputstream', ips)
        if referer:
            if isinstance(referer, dict):
                headers.update(referer)
            else:
                headers['Referer'] = referer
                headers['Origin'] = referer.rsplit('/', 1)[0]
        headers_str = '&'.join(k + '=' + urllib_parse.quote_plus(v) for k, v in headers.items())
        item.setProperty(ips + '.manifest_headers', headers_str)
        item.setProperty(ips + '.manifest_type', 'hls')
    elif clearkey:
        # DASH with clearkey DRM
        item.setPath(stream_url)
        item.setContentLookup(False)
        item.setMimeType('application/dash+xml')
        ips = 'inputstream.adaptive'
        item.setProperty(ips, ips)
        item.setProperty('#KODIPROP:inputstream', ips)
        headers_str = '&'.join(k + '=' + urllib_parse.quote_plus(v) for k, v in headers.items())
        item.setProperty(ips + '.manifest_headers', headers_str)
        # Build clearkey license key
        ck_parts = []
        for kid, key in clearkey.items():
            # Normalize KID: add dashes if needed (format: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX)
            k = kid.replace('-', '')
            if len(k) == 32:
                k = f'{k[0:8]}-{k[8:12]}-{k[12:16]}-{k[16:20]}-{k[20:32]}'
            ck_parts.append('{}:{}'.format(k, key))
        item.setProperty(ips + '.license_key',
                         'mpd:{{"clearkey":{{"keys":"{}"}}}}'.format(','.join(ck_parts)))
        item.setProperty(ips + '.manifest_type', 'mpd')
        item.setProperty(ips + '.stream_selection_type',
                         'ask-quality' if playback == '0' else 'adaptive')
        if playback not in ('0', '1'):
            target_height = int(playback) - 2
            target_heights = [1080, 720, 576, 468, 360, 288]
            if 0 <= target_height < len(target_heights):
                item.setProperty(ips + '.preferred_video_resolution', str(target_heights[target_height]))
    else:
        mime_type = None
        if referer:
            if isinstance(referer, dict):
                # Extract MimeType before merging into HTTP headers
                mime_type = referer.pop('MimeType', None)
                headers.update(referer)
            else:
                headers['Referer'] = referer
        # Build header string - Cookie values must NOT be double-encoded
        hdr_parts = []
        for k, v in headers.items():
            if k == 'Cookie':
                # Cookie values already contain = and ; which should not be encoded
                hdr_parts.append(f'{k}={v}')
            else:
                hdr_parts.append(k + '=' + urllib_parse.quote_plus(v))
        hdr = '&'.join(hdr_parts)
        item.setPath(stream_url + '|' + hdr)
        item.setContentLookup(False)
        if mime_type:
            item.setMimeType(mime_type)

    episode_string = xbmc.getInfoLabel('ListItem.Episode')
    season_info_label = xbmc.getInfoLabel('ListItem.Season')
    item_title = unescapeHTMLText(item.getLabel() or '')
    if episode_string not in ('', '-1'):
        item_info = {
            'tvshowtitle': xbmc.getInfoLabel('ListItem.TVShowTitle'),
            'title': item_title,
            'season': int(season_info_label) if season_info_label.isdigit() else -1,
            'episode': int(episode_string),
            'plot': xbmc.getInfoLabel('ListItem.Plot'),
            'mediatype': 'episode',
        }
    else:
        item_info = {'title': item_title, 'plot': xbmc.getInfoLabel('ListItem.Plot'), 'mediatype': 'movie'}

    item_set_info(item, item_info)
    xbmcplugin.setResolvedUrl(PLUGIN_ID, True, item)


def solve_media_redirect(url, headers):
    """Use (streamed, headers-only) GET requests to fulfill possible 3xx redirections."""
    while True:
        try:
            media_head = rqs_get().get(
                url, stream=True, headers=headers, allow_redirects=False, verify=False, timeout=10
            )
            if 'Location' in media_head.headers:
                url = media_head.headers['Location']
            else:
                media_head.raise_for_status()
                return media_head
        except Exception:
            return None


def main():
    """Main add-on routing function, calls a certain action (function)."""
    params = dict(urllib_parse.parse_qsl(sys.argv[2][1:], keep_blank_values=True))
    globals()[params.get('action', 'actionMenu')](params)
