# -*- coding: utf-8 -*-
from lib.plugin import main

main()
